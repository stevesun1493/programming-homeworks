/*
34. 唯一二元樹
本題必須使用Link List實作，否則不予計分。

給定前序或後序以及中序，請建構唯一的Binary Tree。
輸出該Tree的內容，輸出順序為由上而下，由左而右印出。

前序或後序以及中序代號分別為:
前序代號：P
中序代號：I
後序代號：O

--------------------------------------------------------------------------------------------------------------

輸入說明:
第一行輸入前序、中序或後序的代號。
第二行輸入上一行輸入尋訪的結果，結果皆為大寫英文字母。
第三行輸入前序、中序或後序的代號。
第四行輸入上一行輸入尋訪的結果。

輸出說明
輸出唯一二元樹的內容，輸出順序為由上而下，由左而右。

--------------------------------------------------------------------------------------------------------------

輸入範例 1:
P
ABCDEFGHI
I
BCAEDGHFI

輸出範例 1:
ABDCEFGIH

--------------------------------------------------------------------------------------------------------------

輸入範例 2:
O
CBEHGIFDA
I
BCAEDGHFI

輸出範例 2:
ABDCEFGIH

--------------------------------------------------------------------------------------------------------------

輸入範例 3:
I
EFDAGHCB
O
FEDHGCBA

輸出範例 3:
ADBECFGH

--------------------------------------------------------------------------------------------------------------

輸入範例 4:
O
GIFHBEDCA
I
GFIBHDEAC

輸出範例 4:
ADCBEFHGI

--------------------------------------------------------------------------------------------------------------


輸入範例 5:
P
ABDFIHEGC
I
BAFHEIDGC

輸出範例 5:
ABDFGICHE

--------------------------------------------------------------------------------------------------------------


輸入範例 6:
P
ABCDEFG
I
GFEDCBA

輸出範例 6:
ABCDEFG

--------------------------------------------------------------------------------------------------------------


輸入範例 7:
O
GFEDCBA
I
ABCDEFG

輸出範例 7:
ABCDEFG

--------------------------------------------------------

輸入範例 8:
O
IHGFEDCBA
I
ACEGIHFDB

輸出範例 8:
ABCDEFGHI

--------------------------------------------------------

輸入範例 9:
P
ABCDEFGHIJK
I
FEDCBAGHIJK
                                                        A
                                                    B       G
                                                C               H
                                            D                       I
                                        E                               J            
                                    F                                       K
                                
輸出範例 9:
ABGCHDIEJFK

--------------------------------------------------------

輸入範例 10:
P
ABDHIEJKCFLMGNO
I
HDIBJEK             A           LFMCNGO

輸出範例 10：
ABCDEFGHIJKLMNO

*/



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define TYPE1 1//前序and中
#define TYPE2 0//中and後序


typedef struct node_s
{
    char node_data;

    struct node_s* left;
    struct node_s* right;
}node_t;
typedef struct order_s
{
    int find_idx;//preorder或inorder目前要去inorder找的index
    char inorder[50];
    char preorder[50];
    char postorder[50];
}order_t;

node_t* buildTree(order_t*,int,int,int);//樹頭,起點,終點,前序or後續切
int find(char ,char*);
void BFSprint(node_t*);

int main()
{
    node_t *head=NULL;
    order_t *data=(order_t*)malloc(sizeof(order_t));
    char ch;
    int state;
   
    for(int i=0;i<2;i++)
    {
        ch=getchar();
        if (ch=='I')
        {
            scanf("%s",data->inorder);
            getchar();
        }
        else if(ch=='P')
        {
            scanf("%s",data->preorder);
            state=TYPE1;
            getchar();
        }
        else
        {
            scanf("%s",data->postorder);
            state=TYPE2;
            getchar();
        }
    }
    if(state)
    {
        data->find_idx=0;
        head=buildTree(data,0,strlen(data->inorder)-1,state);
    }
    else
    {
        data->find_idx=strlen(data->inorder)-1;//從後續最後一個切
        head=buildTree(data,0,strlen(data->inorder)-1,state);
    }

    BFSprint(head);

    return 0;

}



node_t* buildTree(order_t *data,int start ,int end,int state)//preorder或inorder的起點和終點的index
{
    if(start>end)//終止條件
        return NULL;
    
    int index;
    // printf("now try to find  root=> %c\n",data->preorder[data->find_idx]);

    index=(state?find(data->preorder[data->find_idx],data->inorder):find(data->postorder[data->find_idx],data->inorder));//第一個點在中序的位子
    // printf("index in inorder is %d\n",index);
    // if(index>=start &&index<=end)
    // {
       
        node_t* node=(node_t*)malloc(sizeof(node_t));
        if(state)
        {
            node->node_data=data->preorder[data->find_idx];
            (data->find_idx)++;//要括弧嗎?//找preorder下一個點
            node->left=buildTree(data,start,index-1,state);
            node->right=buildTree(data,index+1,end,state);
        }
        else
        {
            node->node_data=data->postorder[data->find_idx];
            (data->find_idx)--;//找inorder下一個點
            node->right=buildTree(data,index+1,end,state);
            node->left=buildTree(data,start,index-1,state);
        }
        return node;
    // }
    // else
        // return NULL; 
}


int find(char ch,char* str)
{
    int len=strlen(str);
    for(int i=0;i<len;i++ )
        if(str[i]==ch)
            return i;
}


void BFSprint(node_t* node_head)
{
    node_t *queue[100];//head插入tail離開
    int head=0,tail=0;
    queue[head++]=node_head;
    while(tail!=head)
    {
        if(queue[tail]->left!=NULL)
            queue[head++]=queue[tail]->left;
        if(queue[tail]->right!=NULL)
            queue[head++]=queue[tail]->right;
        putchar(queue[tail]->node_data);
        free(queue[tail]);
        tail++;
    }
}
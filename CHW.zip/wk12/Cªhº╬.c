/*
27. 圖形結構
本題必須使用給定程式碼架構的struct及function pointer實作，否則將不予計分。

請參考給定的程式碼架構，使用 struct 定義以下結構：
Shape（圖形）, Circle（圓形）, Rectangle（矩形）, Square（正方形）,
Triangle（三角形）

圓形有半徑，矩形有長和寬，正方形有邊長，三角形有三個邊。
計算各個圖形的周長與面積，以及所有圖形的周長加總與面積加總。

各圖形的程式碼架構範例如下：
#define ShapeText(TYPE) char name[10];
double (*perimeter)(struct TYPE*);
double (*area)(struct TYPE*)

typedef struct shape_s {
ShapeText(shape_s);
} shape_t;

typedef struct circle_s {
ShapeText(circle_s);
double radius;
} circle_t;

圖形的種類以代號輸入，對應圖形的代號如下：
C：圓形，結構內容具有 1 個 radius 屬性 (圓周率請使用3.14)
R：矩形，結構內容具有 1 個 length、1 個 width 屬性
S：正方形，結構內容具有 1 個 edge 屬性
T：三角形，結構內容具有 3 個 edge 屬性

--------------------------------------------------------------------------------------------------------------

輸入說明:
第一行輸入N ( 2 <= N <= 5 )，代表圖形個數。
其後N行，輸入英文代號代表圖形種類，與該圖形種類的各個屬性，字元間以空格符號相隔開。

輸出說明：
第一行輸出第一個圖形的周長與面積，字元間以空格符號相隔。
第二行輸出第二個圖形的周長與面積，
以此類推，直到N行。
最後一行輸出圖形的周長總和與面積總和。

備註：各個圖形的周長及面積需四捨五入到小數點後第2位，總和請先加總好再四捨五入。

--------------------------------------------------------------------------------------------------------------

輸入範例 1：
2
R 3.98 6.77
S 3.14

輸出範例 1：
21.50 26.94
12.56 9.86
34.06 36.80

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
3
C 3.14159
S 3.14159
T 3.59737 1.56248 2.169984

輸出範例 2：
19.73 30.99
12.57 9.87
7.33 0.88
39.63 41.74

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
4
T 2.2 3.3 4.4
S 1.1
R 1.1 2.2
C 1.0

輸出範例 3：
9.90 3.51
4.40 1.21
6.60 2.42
6.28 3.14
27.18 10.28

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
5
C 3.335
C 3.984
S 315.27
R 4.57 3.18
T 100.5 200 300

輸出範例 4：
20.94 34.92
25.02 49.84
1261.08 99395.17
15.50 14.53
600.50 1226.02
1923.04 100720.49
*/
//參考chat_gpt
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
# define PI 3.14
# define ShapeText(TYPE) char name[10];\
double (*perimeter)(struct TYPE*);\
double (*area)(struct TYPE*);

                         
typedef struct shape_s 
{
    ShapeText(shape_s);
} shape_t;

typedef struct triangle_s //用海龍公式
{
    ShapeText(triangle_s);
    // perimeter=triangle_perimeter;
    double len1;
    double len2;
    double len3;
} triangle_t;

typedef struct rectangle_s 
{
    ShapeText(rectangle_s);
    double length;
    double width;
} rectangle_t;

typedef struct square_s 
{
    ShapeText(square_s);
    double edge;
} square_t;

typedef struct circle_s 
{
    ShapeText(circle_s);
    double radius;
} circle_t;


double sea_dragon(triangle_t* );
double circle_perimeter(circle_t* );
double circle_area(circle_t* );
double rectangle_perimeter(rectangle_t* );
double rectangle_area(rectangle_t* ) ;
double square_perimeter(square_t* );
double square_area(square_t* );
double triangle_perimeter(triangle_t* );
double triangle_area(triangle_t* ); 



void crate_struc_array(shape_t *v[],int );
void print(shape_t *v[],int,double arr[] );

int main() 
{
    int num;
    double final[2]={0,0};
    scanf("%d", &num);
    getchar();//eat'/n'
    
    shape_t **shapes = malloc(num * sizeof(shape_t*));//shapes二維陣列(shape_t的指標陣列),num個指向structure的指標//que1
                                                         //問如果建得是靜態二維shape[i][j]是不是就不能傳成*shape[],要用(*shape)[j]?**shape接可以嗎?
    // for(int i=0;i<num;i++)
    //     shapes[i]=(shape_t*)malloc(sizeof(shape_t));//好像不用打? crate_struc_array裡面已經有建空間了//que2
    for(int i=0;i<num;i++)
            crate_struc_array(shapes,i);
    print(shapes,num,final);
    printf("%.2lf %.2lf\n", final[0],final[1]);
    return 0;
}
void crate_struc_array(shape_t *shapes[],int i)
{
    char type;
    // scanf(" %c", &type);
    type=getchar();
    if(type=='C')
    {
        circle_t* circle = (circle_t*)malloc(sizeof(circle_t));//建指向circle_t物件的指標(給空間)//如果這邊不用指標直接建一個物件circle,然後用shape[i]=&circle是不是會錯?函式結束circle就消失這樣ques3
        scanf("%lf", &circle->radius);
        circle->perimeter = circle_perimeter;//給circle指向的物件的 函式指標(perimeter)指向的地址(函式地指)
        circle->area = circle_area;//同上  給函式指標(area)地址
        shapes[i] = (shape_t*)circle;//circle_t強制轉型成shape_t//que3
    }
    else if(type=='R')
    {
        rectangle_t* rectangle = (rectangle_t*)malloc(sizeof(rectangle_t));//指向rectangle_t的指標
        scanf("%lf %lf", &rectangle->length, &rectangle->width);
        rectangle->perimeter = rectangle_perimeter;
        rectangle->area = rectangle_area;
        shapes[i] = (shape_t*)rectangle;//rectangle從指向rectangle_t結構的指標 強制轉型成指向shape_t結構的指標
    }

    else if(type=='S')
    {
        square_t* square = (square_t*)malloc(sizeof(square_t));
        scanf("%lf", &square->edge);
        square->perimeter = square_perimeter;
        square->area = square_area;
        shapes[i] = (shape_t*)square;
    }

    else
    {
        triangle_t* triangle = (triangle_t*)malloc(sizeof(triangle_t));
        scanf("%lf %lf %lf", &triangle->len1, &triangle->len2, &triangle->len3);
        triangle->perimeter = triangle_perimeter;
        triangle->area = triangle_area;
        shapes[i] = (shape_t*)triangle;                
    }
    getchar();
             
}


void print(shape_t *shapes[],int num,double final[] )
{
    // ;
    // double totalPerimeter = 0;
    // double totalArea = 0;

    for (int i = 0; i < num; i++) {
        printf("%.2lf %.2lf\n", shapes[i]->perimeter(shapes[i]), shapes[i]->area(shapes[i]));
        final[0]+= shapes[i]->perimeter(shapes[i]);
        final[1] += shapes[i]->area(shapes[i]);
        free(shapes[i]);
    }

    
    free(shapes);
}

double circle_perimeter(circle_t* circle) 
{
    double length=2 * PI * circle->radius;
    return length;
}

double circle_area(circle_t* circle) 
{
    double area=PI * circle->radius * circle->radius;
    return area;
}


double rectangle_perimeter(rectangle_t* rectangle) 
{
    double length=2 * (rectangle->length + rectangle->width);
    return length;
}

double rectangle_area(rectangle_t* rectangle) 
{
    double area=rectangle->length * rectangle->width;
    return area;
}


double square_perimeter(square_t* square) 
{
    double length=4 * square->edge;
    return length;
}

double square_area(square_t* square) 
{
    double area=square->edge * square->edge;
    return area;
}

double triangle_perimeter(triangle_t* triangle) 
{
    double length=triangle->len1 + triangle->len2 + triangle->len3;
    return length;
}

double triangle_area(triangle_t* triangle) 
{
    double area=sea_dragon(triangle);

    return area;
}


double sea_dragon(triangle_t* triangle)
{
    double s=(triangle->len1+triangle->len2+triangle->len3)/2;

    return sqrt(s*(s-triangle->len1)*(s-triangle->len2)*(s-triangle->len3));
}
/*
26. 工作排程

有M個工作要在N台機器上加工，每個工作i包含若干個工序Oij，
這些工序須依序加工，也就是前一道工序Oi(j-1)完成後才可開始下一道工序Oij。
每道工序oij可用一個有序對(Kij,Tij)表示它需在機器Kij上面花費Tij小時完成，
而每台機器一次只能處理一道工序。

所謂一道工序Oij的「最早完成時間的Cij｣是指考慮目前排程中機器Kij之可用性
以及前一道工序Oi(j-1)(若該工序存在)之完成時間後可得的最早完成時間。

所有工序的排程規則如下：
針對每一個工作的第一個尚未排程的工序，計算出此工序的「最早完成時間｣，
然後挑選出最早完成時間最小的工序納入排程中，
如果有多個完成時間都是最小，則挑選其中最小工作編號之工序，
一個工序一旦納入排程就不會再更改，重複以上步驟直到所有工序皆納入排程。

範例說明 :
工作1(以○代表) O11 = (2, 4) O12 = (1, 1)
此工作有兩道工序，第一道需要在機器2執行4小時， 第二道需要在機器1執行1小時。

工作2(以■代表) O21 = (0, 2) O22 = (2, 2) O23 = (0, 1)
有三道工序，第一道需要在機器0執行2小時，餘類推。

工作3(以●代表) O31 = (0, 7)
有一道工序需要在機器0執行7小時。

排程過程說明如下:
1. 在開始時，每個工作都是考慮第一道工序，
三個工作第1道工序需要的時間分別是 T11 = 4、T21 = 2、T31 = 7，
這也是它們的最早完成時間， 也就是C11=4、C21=2、C31=7，
因此會先排O21。
====================================
機器0→■■□□□□□□□□□□□□ --------------工作一○
機器1→□□□□□□□□□□□□□□ --------------工作二■
機器2→□□□□□□□□□□□□□□ --------------工作三●
====================================

2. 接下來， 三個工作要考慮的順序分別是工作1的第1個工序、工作2的第2個工序、工作3的第1個工序，即 O11、O22和O31。
(1) O11 需要機器2執行 4小時，而機器 2 尚未安排工序，可以開始加工的時間點是0且O11沒有前一道工序，此工序可以開始的時間是 max(0, 0) = 0，其最早完成時間 C11 = max(0,0) + 4 = 4。
(2) O22 需機器2執行 2小時，而機器 2 尚未安排工序，可以開始加工的時間點是0；但O22前一道工序O21完成時間是 2，因此這工序可以開始的時間是max(0, 2) = 2，最早完成時間 C22 = max(0,2) + 2 = 4。
(3) O31 需機器0執行 7小時，而機器 0 可開始加工的時間點是 2且O31沒有前一道工序，因此這工序可開始的時間是max(2, 0) = 2，其最早完成時間C31 = max(2, 0) + 7 = 9。

經過上述計算，由於C11 和 C22 都是最小，根據規則，工作編號小的先排，所以會排 O11。
====================================
機器0→■■□□□□□□□□□□□□ --------------工作一○
機器1→□□□□□□□□□□□□□□ --------------工作二■
機器2→○○○○□□□□□□□□□□ --------------工作三●
====================================

3. 三個工作目前要考慮的順序分別工作1的第2個工序、工作2的第2個工序、工作3的第1個工序。
依照最早完成時間計算方式，可得到C12 = 5，C22 = 6，C31 = 9，
因此排O12，工作1的工序均已排完，所以工作1的完成時間是 5。
4. 目前剩下工作2與工作3，C22 = 6，C31 = 9，因此先排O22。
5.目前剩下工作2與工作3， C23 = 7，C31 = 9，
因此排O23，工作2的工序已排完，所以工作2的完成時間是 7。
6. 剩下工作3，因為機器0的下一個可以開始時間是7，O31的完成時間是max(7, 0) + 7=14。
====================================
機器0→■■□□□□■●●●●●●● --------------工作一○
機器1→□□□□○□□□□□□□□□ --------------工作二■
機器2→○○○○■■□□□□□□□□ --------------工作三●
====================================

最後所有工作的工序皆有排程，最後三個工作完成時間分別是5、7、14，
因此最後輸出答案 5+7+14=26。

--------------------------------------------------------------------------------------------------------------

輸入說明:
第一行輸入兩個整數 N 與 M，N 代表有多少台機器，M 代表有多少個工作，
接下來會有M個工作資訊 ， 輸入順序即為工作編號順序，
每個工作資訊有兩行，第一行為整數P，代表到工序數量；
第二行有 2 * P 個整數，依序每兩個一組代表一道工序的機器編號與需求時間，每個整數間以空白符號相隔開。
注意: 機器的編號由0開始 。參數N、M、P 以及每個工序的需求時間都是不超過100的正整數。

輸出說明:
輸出每個工作完成時間的總和 。

--------------------------------------------------------------------------------------------------------------

輸入範例 1 :
3 3
2
2 4 1 1
3
0 2 2 2 0 1
1
0 7

輸出範例 1 :
26

--------------------------------------------------------------------------------------------------------------

輸入範例 2 :
2 3
1
0 4
1
1 5
1
1 3

輸出範例 2:
15

--------------------------------------------------------------------------------------------------------------

輸入範例 3 :
4 4
3
0 4 1 8 3 5
4
0 2 0 3 2 4 3 1
1
0 9
2
2 3 3 3

輸出範例 3:
56

--------------------------------------------------------------------------------------------------------------

輸入範例 4 :
5 5
2
0 1 1 2
2
2 3 3 4
2
0 3 4 5
2
0 1 1 1
2
1 1 2 2

輸出範例 4:
29

--------------------------------------------------------------------------------------------------------------

輸入範例 5 :
3 2
10
0 2 1 3 2 4 0 5 1 6 2 7 0 8 1 9 2 10 0 11
10
2 3 1 1 0 2 2 4 1 1 0 5 2 6 1 4 0 3 1 10

輸出範例 5:
119

--------------------------------------------------------------------------------------------------------------

輸入範例 6 :
1 5
3
0 2 0 4 0 6
10
0 2 0 5 0 7 0 9 0 10 0 9 0 7 0 5 0 12 0 7
1
0 30
2
0 14 0 36
5
0 17 0 23 0 7 0 3 0 5

輸出範例 6:
662


*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include<string.h>
typedef struct data_s
{
    int mac_num;//有幾台機器
    int work_num;//有幾項工作
    int ***detail;
}data_t;


void schedule(data_t* ptrdata,int mac_time[],int process_num[],int min_startTime[]);
void clear(int arr[],int);//清0
int total(int*,int);
int findtime(int arr[],int mac_time[],int min_start);
int find_minidx(int arr[],int);

int main()//要傳三圍不固定大小的array是不是只能把array包在structure裡面傳structure到function?//然後問一下這個要怎麼free空間
{
    data_t data;
    scanf("%d",&data.mac_num);
    scanf("%d",&data.work_num);
    int mac_time[data.mac_num];
    int process_num[data.work_num];//存每一項工作有多少程序
    clear(mac_time,data.mac_num);
    int min_startTime[data.work_num];//每種工作的最低起始時間
    clear(min_startTime,data.work_num);

    // memset(mac_time,0,sizeof(int)*data.mac_num);//memset只能用char機器時數全歸0//整數要sizeof(int)
   
    data.detail=(int***)malloc(sizeof(int**)*data.work_num);//三圍動態陣列，存input資訊ok scatter動態?
    for(int i=0;i<data.work_num;i++)
    {
        scanf("%d",process_num+i);//==&process_num[i]?
        data.detail[i]=(int**)malloc(sizeof(int*)*process_num[i]);//**detail[i]=(int**)malloc(sizeof(int*)*process_num[i]);原本寫成這樣錯了
        for(int j=0;j<process_num[i];j++)
        {
            data.detail[i][j]=(int*)malloc(sizeof(int)*2);
            scanf("%d",&data.detail[i][j][0]);//第i項工作第j項程序使用的機台
            scanf("%d",&data.detail[i][j][1]);//第i項工作第j項程序需要的時間
        }
    }
    //test//ok
    // for(int i=0;i<data.work_num;i++)
    // {
    //     printf("work_num.%d has procedure:\n",i);
    //     for(int j=0;j<process_num[i];j++)
    //         printf("machine%d, %dhours. ",data.detail[i][j][0],data.detail[i][j][1]);
    //     printf("\n");
    //     printf("-----------------------------------------------------------------\n");

    // }
    data_t* ptrdata=&data;
    
    schedule(ptrdata,mac_time,process_num,min_startTime);
    printf("%d",total(min_startTime,data.work_num));
    return 0;
}


void schedule(data_t* ptrdata,int mac_time[],int process_num[],int min_startTime[])
{
    int ans[ptrdata->work_num];
    clear(ans,ptrdata->work_num);
    int workdone[ptrdata->work_num];//紀錄目前完成工序
    clear(workdone,ptrdata->work_num);
    int compare_min[ptrdata->work_num];//放每類工作當下最低完成時間
    clear(compare_min,ptrdata->work_num);


    int total_process=total(process_num,ptrdata->work_num);
    // printf("total of %d process\n",total_process);
    for(int i=0;i<total_process;i++)//共有幾項工作要排
    {
        for(int j=0;j<ptrdata->work_num;j++)//每一次比較要丟所有工作類別去排
        {
            if(workdone[j]!=process_num[j])//代表還有工序沒完成
            {
                // printf("-----------------------------------------------------------------\n");
                compare_min[j]=findtime(ptrdata->detail[j][workdone[j]],mac_time,min_startTime[j]);//第j項工作最小完成時間
                // printf("%dth compare  %dth work min complete time is %d\n",i,j,compare_min[j]);
            }
            else//代表第j項工作所有工序皆完成
            {
                compare_min[j]=10000;//給很大的數字
                ans[j]=min_startTime[j];
            }
        }
        int min_idx=find_minidx(compare_min,ptrdata->work_num);//找所有工作誰的最低完成時間最小
        
        mac_time[ptrdata->detail[min_idx][workdone[min_idx]][0]]=compare_min[min_idx];//更新該工序所需機器完成時間
        // printf("fitst put work item%d\n ",min_idx);
        workdone[min_idx]++;//完成工序+1
        min_startTime[min_idx]=compare_min[min_idx];//更新該工作下一個工序的最低起始時間
        // printf("min_startTime for %dth work is now %d\n",min_idx,min_startTime[min_idx]);
        clear(compare_min,ptrdata->work_num);//用來比較最短時間的陣列清0
    }
    
}
int findtime(int data[],int mac_time[],int min_startTime)//找該工序的最快完成時間
{
    // printf("machine %d, hours:%d\n",data[0],data[1]);
    return ((mac_time[data[0]]+data[1])>=(min_startTime+data[1]))?(mac_time[data[0]]+data[1]):(min_startTime+data[1]);
}

int find_minidx(int arr[],int width)
{
    
    int num=arr[0],idx=0;
    for(int i=0;i<width;i++)
    {
        if(arr[i]<num)//同大小選最小工作編號所以用<不用<=
        {
            num=arr[i];
            idx=i;
        }
    }
    return idx;
}


void clear(int arr[],int num)
{
    for(int i=0;i<num;i++)
        arr[i]=0;
}
int total(int*arr,int time)
{
    int sum=0;
    for(int i=0;i<time;i++)
        sum+=*(arr+i);
    return sum;
}
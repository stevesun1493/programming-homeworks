/*
8. 分數運算
(請使用指標實作，未用指標實作者不計分)

給定兩個分數和一個運算符號，請依據題目給定的分數與運算符號進行分數運算
請輸出計算後的結果，需化為最簡分數
最簡分數定義: 分子和分母互質

分數表示格式:
真分數或假分數: 分子/分母
帶分數: 整數(分子/分母)

------------------------------------------------------

輸入說明:
第一行表示第一個分數 (0 <= 分子, 分母 <= 1000)
第二行表示第二個分數 (0 <= 分子, 分母 <= 1000)
第三行表示所做運算，加減乘除分別為+ 、 - 、 * 、 /
第四行表示是否繼續運算: y代表繼續 n代表結束
當繼續運算時，重複第一到第四行輸入


輸出說明:
輸出計算結果，結果分數須化為最簡分數
若輸入分數的分母為0，輸出 error
若計算結果為假分數, 需轉化為帶分數格式輸出
若計算結果為整數，則只需輸出整數
若計算結果為負真分數，需在分子前面輸出負號
若計算結果為負帶分數為，在整數前面輸出負號
若計算結果為 0, 輸出 0

---------------------------------------------------------

範例輸入1:
5/0
11/30
+
y
7/100
2/0
/
n


範例輸出1:
error
error

--------------------------------------------------------

範例輸入2:
-7/30
14/60
+
y
-10/25
-111/23
+
y
457/43
236/33
-
y
78/3
1/2
*
y
-9/28
-4(5/21)
/
n


範例輸出2:
0
-5(26/115)
3(676/1419)
13
27/356

--------------------------------------------------------

範例輸入3:
3(2/5)
98(7/9)
+
y
8(1/4)
9(5/6)
-
y
1(3/7)
1(7/9)
*
y
-7(3/125)
4(3/5)
/
n


範例輸出3:
102(8/45)
-1(7/12)
2(34/63)
-1(303/575)
*/

# include<stdio.h>
# include<stdlib.h>
# include<math.h>/*問一下int a=10;int *ptr=&a; int**ptr2=&ptr3;**ptr2=*ptr這樣ptr2直接指向a嗎??*/
void input(int* son,int* mother,int* int_part);/*問int*a;int c,b;a=&c     *a=b,和a=&b是不是不一樣意思*/
void calculate(char,int,int,int,int,int,int);
void add(int son,int mother,int int_part,int son2,int mother2,int int_part2);
// void minus(int* son,int* mother,int* int_part,int* son2,int* mother2,int* int_part2);
void product(int son,int mother,int int_part,int son2,int mother2,int int_part2);
void division(int son,int mother,int int_part,int son2,int mother2,int int_part2);
void turn_frac(int* ,int* ,int* );
int hfc(int,int);
void display(int*ans_son,int*ans_mom);

int main(void)
{
    int son,mother,int_part,son2,mother2,int_part2;//整數部份為0代表不是帶分數
    //int* ptr_son=&son,ptr_mother=&mother,ptr_int_part=&int_part,ptr_son2=&son2,ptr_mother2=&mother2,ptr_intpart2=&int_part;
    char judge,op;//temp_sym,temp_sym2,
    do 
    {
        input(&son,&mother,&int_part);
        input(&son2,&mother2,&int_part2);
       
        // printf("your input is:\n");
        op=getchar();
        while(getchar()!='\n')//eat 換行
            continue;
        // printf("it's frac with int in main num1:%d,num2:%d\n",int_part,int_part2);//到這都ok
        calculate(op,son,mother,int_part,son2,mother2,int_part2);

        // //test輸入
        // if(int_part!=0)
        //     printf("number1 is %d(%d/%d)\n",int_part,son,mother);
        // else
        //     printf("number1 is %d/%d\n",son,mother);
        // if(int_part2!=0)
        //     printf("number2 is %d(%d/%d)\n",int_part2,son2,mother2);
        // else
        //     printf("number2 is %d/%d\n",son2,mother2);

        // printf("Continue?\n");
       
        scanf("%c",&judge);

    }
    while(judge!='n');
    return 0;
}


void input(int* son,int* mother,int* int_part)
{
        char temp_sym,temp_sym2;
        int temp_int,temp_son,temp_mother;
        *int_part=0;//規0不然會出事
        scanf("%d %c",&temp_int,&temp_sym);//先吃前兩個判斷是不是帶分數//問能不能scanf *指標的值?一定要設一個變數再把值給*指標?
        if (temp_sym=='(')//帶分數
        {   
            
            *int_part=temp_int;
            // printf("it is frac with int:%d\n",*int_part);
            scanf("%d %c%d",&temp_son,&temp_sym2,&temp_mother);
            while(getchar()!='\n')//eat 換行
                continue;
            // printf("temp_son is %d\n",temp_son);
            *son=temp_son;
            *mother=temp_mother;
        }
        else
        {
            *son=temp_int;
            scanf(" %d",&temp_mother);
            while(getchar()!='\n')
                continue;
            //  printf("son is %d\n",*son);
            
            *mother=temp_mother;
        }
        // printf("input function int_part:%d son:%d,mom:%d\n",*int_part,*son,*mother);
}

void calculate( char op,int son,int mother,int int_part,int son2,int mother2,int int_part2)
{
    int temp;
    if(!(mother&&mother2))
    {
        printf("error\n");
        return;
    }
    
    switch (op)
    {
    case '+':
        // printf("oprand is %c\n",op);
        add(son, mother,int_part, son2, mother2, int_part2);
        break;
    case '-':
        // printf("oprand is %c\n",op);
        temp=-1*(son2);
        add(son,mother,int_part,temp,mother2,int_part2);
        break;
    case '*':
        // printf("oprand is %c\n",op);
        product(son, mother,int_part, son2, mother2, int_part2);
        break;
    case '/':
        // printf("oprand is %c\n",op);
        division(son, mother,int_part, son2, mother2, int_part2);
        break;
    default:
        break;
    }
}

void add(int son,int mother,int int_part,int son2,int mother2,int int_part2)
{
    int ans_son,ans_mom;
    // printf("son2 in add is %d\n",*son2);
    turn_frac(&son,&mother,&int_part);//都轉成假分數
    turn_frac(&son2,&mother2,&int_part2);
    // printf("fraction part with + now is number1: %d/%d and number2:%d/%d\n",son,mother,son2,mother2 );
    ans_son=son*(mother2)+son2*(mother);
    ans_mom=(mother)*(mother2);
    // printf("fraction ans after delete int_part before hgf is=%d/%d\n",ans_son,ans_mom);
    display(&ans_son,&ans_mom);
}

void product(int son,int mother,int int_part,int son2,int mother2,int int_part2)
{
    int ans_son,ans_mom;
    turn_frac(&son,&mother,&int_part);//都轉成假分數
    turn_frac(&son2,&mother2,&int_part2);
    // printf("fraction part with * now is number1: %d/%d and number2:%d/%d\n",son,mother,son2,mother2 );
    ans_son=son*(son2);
    ans_mom=(mother)*(mother2);
    display(&ans_son,&ans_mom);
}
void division(int son,int mother,int int_part,int son2,int mother2,int int_part2)
{
    int ans_son,ans_mom;
    turn_frac(&son,&mother,&int_part);//都轉成假分數
    turn_frac(&son2,&mother2,&int_part2);
    // printf("fraction part with / now is number1: %d/%d and number2:%d/%d\n",son,mother,son2,mother2 );
    if (son2<0)
    {
        son2*=-1;
        mother2*=-1;
    }
    ans_son=son*(mother2);
    ans_mom=(mother)*(son2);
    // printf("After division is: %d/%d \n",ans_son,ans_mom);
    display(&ans_son,&ans_mom);
}

void turn_frac(int* son,int* mother,int* int_part)
{
    if (*int_part==0)
        *son=*son;
    else if ((*int_part*(*son)<0))
        *son=-1*(abs(*int_part)*(*mother)+abs(*son));
    else
        *son=(*int_part)*(*mother)+abs(*son);
}

void display(int*ans_son,int*ans_mom)
{
    int ans_int,common=0;
    if (*ans_son==0)
        printf("0\n");
    else if(abs(*ans_son)>abs(*ans_mom))
    {
        ans_int=*ans_son/(*ans_mom);
        *ans_son%=*ans_mom;
        *ans_son=abs(*ans_son);
        // printf("ans_son and mom now is %d and %d\n",*ans_son,*ans_mom);
        while(common!=1)
        {
            common=hfc(*ans_son,*ans_mom);
            // printf("common number is %d\n",common);
            *ans_son/=common;
            // printf("ans_son now is %d\n",*ans_son);
            *ans_mom/=common;
            // printf("ans_mom now is %d\n",*ans_mom);
        }
        if(*ans_son==0)
            printf("%d\n",ans_int);
        else
            printf("%d(%d/%d)\n",ans_int,*ans_son,*ans_mom);
    }
    else if(abs(*ans_son)<abs(*ans_mom))
    {
        // printf("ans_son and mom now is %d and %d\n",*ans_son,*ans_mom);
        while(common!=1)
        {
            common=hfc(*ans_son,*ans_mom);
            *ans_son/=common;
            *ans_mom/=common;
        }
        printf("%d/%d\n",*ans_son,*ans_mom);
    }
    else
        printf("1\n");
}
int hfc(int a,int b)//a<b
{
    for(int i=2;i<abs(a+1);i++)
        if((a%i==0&&b%i==0))//兩個都能整除
            return i;
    return 1;
}






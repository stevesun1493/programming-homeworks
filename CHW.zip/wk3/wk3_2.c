# include<stdio.h>
# include<stdlib.h>
# include<math.h>
void run();
void run2();
int hfc(int ,int );
int main(void)
{
    int type;
    scanf("%d",&type);
    if (type==1)
        run();
    else
        run2();
    return 0;
}
void run2()
{
    double l1[3],l2[3],l3[3];
    double ans[3][2];

    scanf("%lf %lf %lf",l1,l1+1,l1+2);//問助教不能寫scanf("%lf %lf %lf",&l1[0],&l1[1],&l1[2])?
    getchar();
    scanf("%lf %lf %lf",l2,l2+1,l2+2);
    getchar();
    scanf("%lf %lf %lf",l3,l3+1,l3+2);
    getchar();
    ans[0][0]=(l2[2]*l1[0]-l1[2]*l2[0])/(l1[1]*l2[0]-l1[0]*l2[1]);
    ans[0][1]=(l1[2]*l2[1]-l2[2]*l1[1])/(l1[0]*l2[1]-l1[1]*l2[0]);
    ans[1][0]=(l3[2]*l1[0]-l1[2]*l3[0])/(l1[1]*l3[0]-l1[0]*l3[1]);
    ans[1][1]=(l1[2]*l3[1]-l3[2]*l1[1])/(l1[0]*l3[1]-l1[1]*l3[0]);
    ans[2][0]=(l3[2]*l2[0]-l2[2]*l3[0])/(l2[1]*l3[0]-l2[0]*l3[1]);
    ans[2][1]=(l2[2]*l3[1]-l3[2]*l2[1])/(l2[0]*l3[1]-l2[1]*l3[0]);

    for(int i=0;i<3;i++)
        for(int j=i+1;j<3;j++)
        {
            if(ans[j][0]<ans[i][0])
            {
                double temp = ans[i][0];
                double temp2= ans[i][1];
                ans[i][0]= ans[j][0];//問為啥不能直接ans[i]=ans[j]
                ans[i][1] = ans[j][1];
                ans[j][0]=temp;
                ans[j][1]=temp2;
            }
            else if(ans[j][0]==ans[i][0])
            {
                if(ans[j][1]<ans[i][1])
                {
                    double temp = ans[i][0];
                    double temp2= ans[i][1];
                    ans[i][0]= ans[j][0];
                    ans[i][1] = ans[j][1];
                    ans[j][0]=temp;
                    ans[j][1]=temp2;
                }
            }
        }
    // printf("(x=%5.2lf,y=%5.2lf)\n",(l2[2]*l1[0]-l1[2]*l2[0])/(l1[1]*l2[0]-l1[0]*l2[1]),(l1[2]*l2[1]-l2[2]*l1[1])/(l1[0]*l2[1]-l1[1]*l2[0]));
    // printf("(x=%5.2lf,y=%5.2lf)\n",(l3[2]*l1[0]-l1[2]*l3[0])/(l1[1]*l3[0]-l1[0]*l3[1]),(l1[2]*l3[1]-l3[2]*l1[1])/(l1[0]*l3[1]-l1[1]*l3[0]));
    // // printf("(x=%5.2lf,y=%5.2lf)\n",(l3[2]*l2[0]-l2[2]*l3[0])/(l2[1]*l3[0]-l2[0]*l3[1]),(l2[2]*l3[1]-l3[2]*l2[1])/(l2[0]*l3[1]-l2[1]*l3[0]));
    printf("(%.2lf, %.2lf)\n",ans[0][0]==0?0:ans[0][0],ans[0][1]==0?0:ans[0][1]);//問-0怎麼處理
    printf("(%.2lf, %.2lf)\n",ans[1][0]==0?0:ans[1][0],ans[1][1]==0?0:ans[1][1]);
    printf("(%.2lf, %.2lf)\n",ans[2][0]==0?0:ans[2][0],ans[2][1]==0?0:ans[2][1]);

    // printf("(%.2lf, %.20lf)\n",ans[0][0],ans[0][1]);//問-0怎麼處理
    // printf("(%.2lf, %.2lf)\n",ans[1][0],ans[1][1]);
    // printf("(%.2lf, %.2lf)\n",ans[2][0],ans[2][1]);

}

void run()
{
    int num;
    int x1,y1,x2,y2,m_son,m_mom,b_son,b_mom,common=0;
    scanf("%d",&num);
    for(int i=0;i<num;i++)
    {
        scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
        getchar();
        m_son=(y1 - y2);
        m_mom=(x1 - x2);
        if (m_son!=0)
            while(common!=1)
            {
                common=hfc(m_son,m_mom);
                m_son/=common;
                m_mom/=common;
            }
        common=0;
        b_son=(x2 * y1 - x1 * y2);
        b_mom=(x2 - x1);
        if (b_son!=0)
            while(common!=1)
            {
                common=hfc(b_son,b_mom);
                b_son/=common;
                b_mom/=common;
            }


        common=0;   
        // printf("m_son=%d,b_son=%d\n",m_son,b_son);
        if(m_son!=0&&b_son!=0)//False代表其中一個是0//問有沒其他寫法?寫到死
        {
            if(abs(m_son)==abs(m_mom)&&abs(b_son)!=abs(b_mom))//m=1or-1,b!=1and b!=-1
                if(m_son*m_mom<0)//m=-1
                    if (b_son*b_mom>0)
                        if(b_son%b_mom==0)//b為!=1or-1的常數
                            printf("y = -x + %d\n",abs(b_son)/abs(b_mom));
                        else
                            printf("y = -x + %d/%d\n",abs(b_son),abs(b_mom));
                    else
                        if(b_son%b_mom==0)//b為!=1or-1的常數
                            printf("y = -x - %d\n",abs(b_son)/abs(b_mom));
                        else
                            printf("y = -x - %d/%d\n",abs(b_son),abs(b_mom));
                else //m=1
                    if (b_son*b_mom>0)
                        if(b_son%b_mom==0)
                            printf("y = x + %d\n",abs(b_son)/abs(b_mom));
                        else
                            printf("y = x + %d/%d\n",abs(b_son),abs(b_mom));
                    else
                        if(b_son%b_mom==0)
                            printf("y = x - %d\n",abs(b_son)/abs(b_mom));
                        else
                            printf("y = x - %d/%d\n",abs(b_son),abs(b_mom));
            else if (abs(m_son)==abs(m_mom)&&abs(b_son)==abs(b_mom))
            {
                // printf("here\n");
                // printf("b_son=%d,b_mom=%d\n",b_son,b_mom);
                if(m_son*m_mom<0)
                    if (b_son*b_mom>0)
                        printf("y = -x + 1\n");
                    else
                        printf("y = -x - 1\n");
                else 
                    if (b_son*b_mom>0)
                        printf("y = x + 1\n");
                    else
                        printf("y = x - 1\n");
            }
            
            else
                //printf("enter here\n");
                if(m_son>0&&m_mom<0&&b_son*b_mom<0)//b<0
                    if(abs(m_mom)==1&&abs(b_mom)==1)
                        printf("y = %dx - %d\n",-1*m_son,abs(b_son));
                    else if(abs(m_mom)==1&&abs(b_mom)!=1)
                        printf("y = %dx - %d/%d\n",-1*m_son,abs(b_son),abs(b_mom));
                    else if(abs(m_mom)!=1&&abs(b_mom)==1)
                        printf("y = %d/%dx - %d\n",-1*m_son,abs(m_mom),abs(b_son));
                    else
                        printf("y = %d/%dx - %d/%d\n",-1*m_son,abs(m_mom),abs(b_son),abs(b_mom));
                else if(m_son<0&&m_mom>0&&b_son*b_mom<0)//b<0
                    if(abs(m_mom)==1&&abs(b_mom)==1)
                        printf("y = %dx - %d\n",m_son,abs(b_son));
                    else if(abs(m_mom)==1&&abs(b_mom)!=1)
                        printf("y = %dx - %d/%d\n",m_son,abs(b_son),abs(b_mom));
                    else if(abs(m_mom)!=1&&abs(b_mom)==1)
                        printf("y = %d/%dx - %d\n",m_son,abs(m_mom),abs(b_son));
                    else
                        printf("y = %d/%dx - %d/%d\n",m_son,abs(m_mom),abs(b_son),abs(b_mom));
                else if(m_son*m_mom>0&&b_son*b_mom<0)//b<0
                    if(abs(m_mom)==1&&abs(b_mom)==1)
                        printf("y = %dx - %d\n",abs(m_son),abs(b_son));
                    else if(abs(m_mom)==1&&abs(b_mom)!=1)
                        printf("y = %dx - %d/%d\n",abs(m_son),abs(b_son),abs(b_mom));
                    else if(abs(m_mom)!=1&&abs(b_mom)==1)
                        printf("y = %d/%dx - %d\n",abs(m_son),abs(m_mom),abs(b_son));
                    else
                        printf("y = %d/%dx - %d/%d\n",abs(m_son),abs(m_mom),abs(b_son),abs(b_mom));
                else if(m_son*m_mom<0&&b_son*b_mom>0)//ms*mm>0,ms,mm其中一個<0
                    if(abs(m_mom)==1&&abs(b_mom)==1)
                        printf("y = %dx + %d\n",m_son/m_mom,abs(b_son));
                    else if(abs(m_mom)==1&&abs(b_mom)!=1)
                        printf("y = %dx + %d/%d\n",m_son/m_mom,abs(b_son),abs(b_mom));
                    else if(abs(m_mom)!=1&&abs(b_mom)==1)
                        printf("y = %d/%dx + %d\n",-1*abs(m_son),abs(m_mom),abs(b_son));
                    else//m,b都不是整數
                        printf("y = %d/%dx + %d/%d\n",-1*abs(m_son),abs(m_mom),abs(b_son),abs(b_mom));
                else//m,b(分子分母同號)都>0
                    if(abs(m_mom)==1&&abs(b_mom)==1)
                        printf("y = %dx + %d\n",abs(m_son),abs(b_son));
                    else if(abs(m_mom)==1&&abs(b_mom)!=1)
                        printf("y = %dx + %d/%d\n",abs(m_son),abs(b_son),abs(b_mom));
                    else if(abs(m_mom)!=1&&abs(b_mom)==1)
                        printf("y = %d/%dx + %d\n",abs(m_son),abs(m_mom),abs(b_son));
                    else
                        printf("y = %d/%dx + %d/%d\n",abs(m_son),abs(m_mom),abs(b_son),abs(b_mom));

        }
        else//m or b=0
        {
           // printf("enter test\n");
            if(b_son!=0)//m=0
                if(abs(b_mom)==1)
                    printf("y = %d\n",b_son/b_mom);
                else
                    printf("y = %d/%d\n",b_son,b_mom);
            else if(m_son!=0)//b=0
                if(abs(m_mom)==1)
                    if(abs(m_son)==1 && (m_mom)*m_son>0)
                        printf("y = x\n");
                    else if (abs(m_son)==1 && (m_mom)*m_son<0)
                        printf("y = -x\n");
                    else                
                        printf("y = %dx\n",m_son/m_mom);
                else
                    printf("y= %d/%dx\n",m_son,m_mom);
            else//兩個都0
                printf("y = 0\n");
        }
    }
}


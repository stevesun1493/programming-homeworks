/*
12. 大數運算

給定一個字元符號決定大數運算的模式，
大數運算模式分為以下三種:
1. 字元'+' 代表大數相加
2. 字元'-' 代表大數相減
3. 字元'*' 代表大數相乘

題目會給予兩個20~40位數(包含上下限)的長正整數做運算，//乾只會是正整數哭喔
請根據大數運算模式計算並輸出結果。

---------------------------------------------------

輸入說明:
第一行輸入一個字元符號 C，C表示大數運算的模式
第二行輸入第一個長正整數數 N (20 <= strlen(N) <= 40)
第三行輸入第二個長正整數 M (20 <= strlen(M) <= 40)

輸出說明:
跟據大數運算模式輸出計算結果

---------------------------------------------------

範例輸入 1：
+
9578977894569458768957689498576
3879820923099819028419182498493572571412

範例輸出 1：
3879820932678796922988641267451262069988

---------------------------------------------------

範例輸入 2：
+
12903129413974305729385092389023492
17984731893298742340


範例輸出 2：
12903129413974323714116985687765832

---------------------------------------------------

範例輸入 3：
+
9749823749999999999991284901093564590
9749823749999999999991284901093564590


範例輸出3：
19499647499999999999982569802187129180

---------------------------------------------------

範例輸入 4：
-
9749823749999999999991284901093564590
9749823749999999999991284901093564590

範例輸出 4：
0

---------------------------------------------------

範例輸入 5：
-
12903129413974305729385092389023492
17984731893298742340

範例輸出 5：
12903129413974287744653199090281152

---------------------------------------------------

範例輸入 6：
-
9578977894569458768957689498576
3879820923099819028419182498493572571412

範例輸出 6：
-3879820913520841133849723729535883072836

---------------------------------------------------

範例輸入 7：
*
9999999999999999999999999999999999999999
9999999999999999999999999999999999999999

範例輸出 7：
99999999999999999999999999999999999999980000000000000000000000000000000000000001
---------------------------------------------------

範例輸入 8：
*
12903129413974305729385092389023492
17984731893298742340

範例輸出 8：
232059323094864807208258211161094268960043424315051280

---------------------------------------------------

範例輸入 9：
*
9578977894569458768957689498576
3879820923099819028419182498493572571412

範例輸出 9：
37164718857261238475272616357976303756722706439685013931690425232309312
*/
//問如果宣告一個字串後面想要一直改字串內容是不是只能用指標宣告?main丟array,function用指標接，可以function內修改來讓main裡面的字元陣列內容改變麻?
#include<stdio.h>//問null==0位麼是true
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>//布林
void addnum(int*,int,int*,int);
void minus(int*,int,int*,int,int*);
void product(int*,int,int*,int);
void productAdd(int*,int*,int);
void transfer(char*,int*);
bool judge_size(char*,char*,int*,int*);
bool samelen_judge(char*,char*,int*,int*);


int main(void)
{
    char temp_a[50]="",temp_b[50]="",op;//
    int a=0;
    int *sign=&a;//原本宣告char *sign會錯ㄟ為什麼?y
    int num_a[50]={0},num_b[50]={0},lenA,lenB;//原本沒初始有殘值答案才有錯
    int same=0;//判斷相減數是否為同一個數
    // printf("test residue: %d\n",num_a[21]);//測殘值
    op=getchar();
    getchar();// eat \n
    scanf("%s",temp_a);//輸入1
    getchar();
    scanf("%s",temp_b);//輸入2

    if(op=='+')
    {
        transfer(temp_a,num_a);
        transfer(temp_b,num_b);
        lenA=strlen(temp_a);
        lenB=strlen(temp_b);
        addnum(num_a,lenA,num_b,lenB);
    }
    else if(op=='-')
    {
        if(judge_size(temp_a,temp_b,&same,sign)&& same==-1)//代表兩數一樣，相減為0//sign用來判斷結果前面的伏後是正還負//問黃色經泰號沒給初值會怎樣?
         {
            //    printf("two number are same\n");
               printf("0\n");
               return 0;
         }
        else if(judge_size(temp_a,temp_b,&same,sign))//A比B大
        {
            // printf("numA is larger than B\n");
            transfer(temp_a,num_a);
            transfer(temp_b,num_b);
            lenA=strlen(temp_a);
            lenB=strlen(temp_b);
            // printf("sign is %c\n",*sign);
            minus(num_a,lenA,num_b,lenB,sign);
        }
        else//B比A大
        {
            // printf("numB is larger than A");
            transfer(temp_a,num_a);
            transfer(temp_b,num_b);   
            lenA=strlen(temp_a);
            lenB=strlen(temp_b);     
            // printf("sign is %c\n",*sign);
            minus(num_b,lenB,num_a,lenA,sign);
        }

    }
    else if (op=='*')
    {
        // printf("*mode\n");
        transfer(temp_a,num_a);
        transfer(temp_b,num_b);  
        lenA=strlen(temp_a);
        lenB=strlen(temp_b);    
        product(num_a,lenA,num_b,lenB);
    }



     



    //  // test 輸入數字轉換arr(反轉)
    // printf("\nreverse numA is:");
    // for(int i=0;i<lenA;i++)
    // {
    //     printf("%d",num_a[i]);
    // }
    // printf("\nreverse numB is:");

    // for(int i=0;i<lenB;i++)
    //     printf("%d",num_b[i]);
    // printf("\n");



    return 0;




    // printf("%d\n",*(ans+i));
    // // while(*(ans+i++)!=-1);
    // i-=2;//數字有i位
    // printf("i=%d\n",i);
    // for(int j=i;j>=0;j--)
    //     printf("%d\n",*(ans+i));


    //test input
    // for(int i=0;i<50;i++)
    // {
    //     if(temp_a[i]!='\0')
    //         printf("%c",temp_a[i]);
    //     else
    //         break;
    // }
    // printf("\n");
    // for(int i=0;i<50;i++)
    // {
    //     if(temp_b[i]!='\0')
    //         printf("%c",temp_b[i]);
    //     else
    //         break;
    // }
    

    
}

void transfer(char* str,int* num)
{
    int len=strlen(str);
    // printf("input lengh is:%d\n",len);
    for(int i=len-1;i>=0;i--)
    {
        num[len-1-i]=str[i]-'0';
    }
}
bool judge_size(char* numA,char*numB,int* same,int* sign)
{
    // printf("len A is %d\n",strlen(numA));
    // printf("len B is %d\n",strlen(numB));//test
    if (strlen(numA)>strlen(numB))
    {
        *sign=1;
        return true;
    }
    else if (strlen(numA)<strlen(numB))
    {
        *sign=-1;
        return false;
    }
    else
        return(samelen_judge(numA,numB,same,sign));

}

bool samelen_judge(char* numA,char* numB,int* same, int* sign)
{
    if(strcmp(numA,numB)==0)
    {
        *same=-1;//代表相減為0
        return true;
    }
    else if(strcmp(numA,numB)>0)
    {
        *sign=1;
        // printf("A>B\n");
        return true;
    }
    else
    {
        *sign=-1;
        return false;
    }
}

void addnum(int num_a[],int lenA,int num_b[],int lenB)
{
    int ans[80];
    int len= lenA>=lenB?lenA:lenB,carry=0;//carry=1有進位
    // ptr_arr=ans;
    for(int i=0;i<=len+1;i++)//最後一為進位有問題!!
        if (carry==0)//第0位or第i-1位沒進位
        {
            ans[i]=(num_a[i]+num_b[i])%10;
            if(i==len)//到最後一位or倒數第一位了(看還有沒有要進位)
            {
                ans[len]=-1;//終止值為-1
                break;
            }
            else if(i==len+1)
            {
                ans[len+1]=-1;
                // printf("last need add1 test \n");
                break;
            }
            carry=(num_a[i]+num_b[i])/10;
        }
        else//第i-1位有進位
        {
            ans[i]=(num_a[i]+num_b[i]+1)%10;//最後一為變成null+null+1(0+0+1?)
            carry=(num_a[i]+num_b[i]+1)/10;
        }  
    
    int index=0;
    // while(ans[index++]!=-1)//index會錯why?

    
    while(ans[index]!=-1)
         index++;
    // printf("index for -1 is:%d\n",index);
    // printf("answer is:");
    for(int k=index-1;k>=0;k--)
        printf("%d",ans[k]);

    return;//想問丟回去main在印出來的寫法(function才比較通用)
    // printf("number after add is:");
    // for(int j=index-1;j>=0;j--)
    //     printf("%d",ans[j]);
    // return ptr_arr;//丟 pointer回去
}

void minus(int numA[],int lenA,int numB[],int lenB,int* sign)
{
    int ans[50],carry=0;
    int len=lenA>lenB?lenA:lenB;//因為lenA>=lenB//len為答案最大可能長度
    // printf("possible largest len for ans is %d\n",len);
    for(int i=0;i<=len-1;i++)  
        if((numA[i]-carry)>=numB[i])//不用跟前面借數字
        { 
            ans[i]=numA[i]-carry-numB[i];
            // printf("for reversed %d th,ans[%d]=%d\n",i+1,i,ans[i]);
            carry=0;
        }
        else if((numA[i]-carry)<numB[i])
        {
            ans[i]=numA[i]-carry+10-numB[i];//+10跟前面借一位
            // printf("for reversed %d th,ans[%d]=%d\n",i+1,i,ans[i]);
            carry=1;
        }

    //test 找尾巴數來第一個不為0的index
    int index;
    for(int i=len-1;i>=0;i--)//最後一位開始找
            if(ans[i]!=0)
            {
                index=i;//即後面數來第ans[index]!=0
                break;    
            }
    // printf("ans is :");//test output
    if(*sign==-1)
        printf("-");
    for(int i =index;i>=0;i--)
        printf("%d",ans[i]);
    
}



void product(int numA[],int lenA,int numB[],int lenB)
{
    int ans[80]={0},temp[80]={0},carry=0;//乘完放temp再去加ans

    for(int i=0;i<lenB;i++)//B一個一個數去乘A
    {
        for(int j=0;j<lenA;j++)
        {
            temp[j]=numB[i]*numA[j]+carry;
            carry=temp[j]/10;
            temp[j]%=10;
            if(j==lenA-1)
                temp[lenA]=carry;

        }
        //test乘法//OK
        // printf("test temp=:");//測B的每一位數*A的值
        // for(int k=lenA;k>=0;k--)
        //     printf("%d",temp[k]);


        productAdd(ans,temp,i);//i代表從第幾個index開始相加

        for(int k=0;k<80;k++)//清0//問有沒其他寫法
            temp[k]=0;
        carry=0;//忘記歸0所以temp有時候第一位會+1
    }
    int index;
    for(int i=79;i>=0;i--)
    {
        if(ans[i]!=0)
        {
            index=i;
            // printf("index for ans not 0 is %d and value is %d\n",index,ans[index]);
            break;
        }
    }
    // printf("\ntest answer for product is:");
    for(int i=index;i>=0;i--)
        printf("%d",ans[i]);
}


void productAdd(int ans[],int temp[],int index)
{
    // printf("\ncall pro add one time and start add from %d index\n",index);
    int carry=0;
    int j=0;//temp記得每次從temp[0]開始加，ans從ans[index]開始
    for (int i=index;i<80;i++)//
    {
        
        // printf("add ans[%d]=%d,temp[%d]=%d\n",i,ans[i],i,temp[i]);
        if(carry==0)
        {
            carry=(ans[i]+temp[j])/10;
            ans[i]=(ans[i]+temp[j])%10;
        }
        else if(carry==1)//要進位
        {
            carry=(ans[i]+1+temp[j])/10;
            ans[i]=(ans[i]+1+temp[j])%10;
        }
        j++;
    }
}
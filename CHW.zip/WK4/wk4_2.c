/*
11. 電路模擬

模擬一個數位IC，內有回饋電路與紀錄器電路。
輸入M 是二進位 12 位元，輸出是二進位 4 位元。
輸入範圍從 000000000000 到 111111111111 (十進位 0~4095)

數位IC內有一個回饋電路,回饋方式:
C(M) = M 當 M (十進位) 為 0 或 M 為 1 時
C(M) = C(M/2) 當 M (十進位) 為偶數
C(M) = C((M+1)/2) 當 M (十進位) 為奇數

請以二進位輸出回饋次數
並且以十進位輸出每次回饋的數值，中間以一個數字分隔

例如 M=000000001010 (十進位 10),則電路回饋依序為十進位 5, 3, 2, 1。
C(10)= C(5)=C(3)=C(2)=C(1)=1，共回饋 4 次。
數位IC內有一個紀錄器R，會記錄回饋電路的回饋次數。
R(M) = [C(M) 的回饋次數]，例如 R(10) = 4，
則此數位IC以二進位輸出回饋次數為 0100。
當輸入為-1時，則結束執行。

輸入範例 1：
000000101010
-1

輸出範例 1：
0110
21 11 6 3 2 1

---------------------------------------------------

輸入範例 2：
000000000000
111001001100
111111111111
-1

輸出範例 2：
0000
No Feedback
1100
1830 915 458 229 115 58 29 15 8 4 2 1
1100
2048 1024 512 256 128 64 32 16 8 4 2 1

---------------------------------------------------

輸入範例 3：
101010101010
010101010101
011001100110
100100111001
011100100110
-1

輸出範例 3：
1100
1365 683 342 171 86 43 22 11 6 3 2 1
1011
683 342 171 86 43 22 11 6 3 2 1
1011
819 410 205 103 52 26 13 7 4 2 1
1100
1181 591 296 148 74 37 19 10 5 3 2 1
1011
915 458 229 115 58 29 15 8 4 2 1



*/


# include<stdio.h>
# include<stdlib.h>
# include<string.h>
# include<math.h>
int two_to_ten(char*);
void Cin(int);
void ten_to_two(int );
int Cin2(int ,int );//先印回饋次數變成我要跑兩次幾乎一樣的函示?
int main()
{
    int time=0,ans;
    int num_input;
    char input[100]="";
    while(1)
    {
        //char input[100]="";宣告在這裡是不是每一次input陣列位置都會換?
        scanf("%s",input);
        // printf("input is %s test\n",input);
        getchar();
        if(input[0]=='-')
            break;
        num_input=two_to_ten(input);
        
        if (num_input==0)
        {
            printf("0000\n");
            printf("No Feedback\n");
        }
        else
        {
            ans=Cin2(num_input,time);
            ten_to_two(ans);
            printf("\n");
            Cin(num_input);
            time=0;
            printf("\n");
            // printf("\ntime is %d\n",ans);
            // printf("input number is %d\n",num_input);
        }
        for(int i=0;i<100;i++)//迴圈清空字元陣列，塞下一圈
            input[i]=NULL;//問黃色驚嘆號
    }
    return 0;
}


int two_to_ten(char* input_2)
{
    // printf("size of input is %d",sizeof(input_2));//這個會錯問一下why always 4=>輸出的是adress的size
    int length=strlen(input_2),input_10=0,temp;
    //printf("input is %d long",length);//test length
    for(int i=length-1;i>=0;i--)//問i可以不給初值?
    {
        // printf("%c",input_2[i]);//test reverse input
        
        // input_2[i]=='1'?temp=1:temp=0;//這樣為什麼會錯
        if(input_2[i]=='0')
            temp=0;
        else
            temp=1;
        input_10+=temp*pow(2,length-1-i);
        temp=0;
    }
    return input_10;
}


void Cin(int input)
{
    if(input==0||input==1)
        return ;
    else if(input%2==0)
    {
        printf("%d ",input/2);
        Cin(input/2);
        
    }
    else if((input+1)%2==0)
    {
        printf("%d ",(input+1)/2);
        Cin((input+1)/2); 
    }
}

void ten_to_two(int num)
{
    int i=0,ans_temp[4];
    while (num>0)   
    {
        // printf("num is %d\n", num);
        ans_temp[i++] = num%2;  
        // printf("2digit revese=%d\n",ans_temp[i-1]);
        if (num/2==0)
            ans_temp[i]=0;
        num = num/2;
    }
    int temp=i;
    // printf("temp=%d\n",temp);
    for(i=0; i<4; i++)
        printf("%d",ans_temp[3-i]);
}



int Cin2(int input,int time)
{
    if(input==0||input==1)
        return time;
    else if(input%2==0)
    {
        time++;
        Cin2(input/2,time);
        
    }
    else if((input+1)%2==0)
    {
        time++;
        Cin2((input+1)/2,time); 
    }
}
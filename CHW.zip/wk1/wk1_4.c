# include<stdio.h>
# include<stdlib.h>

int main(void)
{
    int s0,s1,add1,add2,add3,del1,del2,del3,finalS1;
    scanf("%d",&s0);
    fflush(stdin);
    scanf("%d",&s1);
    fflush(stdin);
    scanf("%d %d %d",&add1,&add2,&add3);
    fflush(stdin);
    scanf("%d %d %d",&del1,&del2,&del3);
    finalS1=s1;
    finalS1=finalS1|(1<<add1);
    finalS1=finalS1|(1<<add2);
    finalS1=finalS1|(1<<add3);

    finalS1=finalS1&~(1<<del1);
    finalS1=finalS1&~(1<<del2);
    finalS1=finalS1&~(1<<del3);    

    if ((s0|finalS1)==s0)
        printf("Y\n");
    else
        printf("N\n");
    printf("%d\n",s1&finalS1);
    printf("%d",s1|finalS1);
    return 0;
}
/*
題目2 - 跑壘問題

根據棒球隊球員打擊結果，計算出球隊的得分。

棒球規則如下：
球場上有四個壘包， 稱為本壘、一、二和三壘。
本壘握球棒打的稱「擊球員」 ，在另外三個壘包的稱為「跑員」。
當擊球員打擊「安打」時， 擊球員與跑壘員可移動；
「出局」時，跑壘員不動，擊球員離場換下一位。

擊球員打擊情況如下：
安打：以1, 2, 3 和 H 代表一、二、三和全(四)壘打。
出局：以 O 表示出局。

比賽開始由第 1位打擊，接著2, 3, 4, 5位球員。
打出 K 壘打時，場上球員(擊球員和跑壘員)會前進 K個壘包。
本壘到一壘，接著二、三壘，最後回到本壘。回到本壘可得 1分。
每達到三個出局數時，壘包清空(跑壘員都得離開)，重新開始。

最後根據5位擊球員打擊情況，計算出球隊得分與一、二、三壘的情況，有人為1，沒人為0。

---------------------------------------------------

輸入說明:
第一行為第一位打者的打擊情況，以1, 2, 3 和 H 代表一、二、三和全(四)壘打，以 O 表示出局。
其後四行為接續四位打者的打擊狀況。

輸出說明:
第一行輸出球隊得分，
第二行分別輸出一壘、二壘、三壘的情況，以空白符合相隔開。

---------------------------------------------------

範例輸入1：
1
1
O
O
1

範例輸出1：
0
1 1 1

---------------------------------------------------

範例輸入2：
3
O
O
O
2

範例輸出2：
0
0 1 0

---------------------------------------------------

範例輸入3：
H
H
H
H
1

範例輸出3：
4
1 0 0

---------------------------------------------------

範例輸入4：
1
3
O
2
1

範例輸出4：
2
1 0 1
*/

# include<stdio.h>
# include<stdlib.h>
int input(char);

int main(void)
{
    int state=0,count=0,copy_state;//state是壘包狀態,count用來算出局數
    static int score=0;//用來存分數
    for(int i=0;i<10;i++)
    {
        char num;
        int result;
        num=getchar();
        if (num=='\n')
            continue;
        else
        //scanf(" %s",&num);
        // fflush(stdin);
            result=input(num);//num沒再宣告成整數為什麼不會有錯?
            // printf("%d\n",result);//測試輸入
       
        if (result==0)/*用來看友梅三出局*/
            count++;
        else if (count==3)
            state=0;//三出局壘包歸0
        
        if (result==0)/*更新壘包情況*/
            state=state; //這行有其他寫法嗎?感覺在發呆
        else
            state = (state << result) | (1<<(result-1));
        copy_state=state;
        copy_state=(copy_state>>3);
        // printf("copy is %d\n",copy_state);//test
        if (copy_state==1||copy_state==2||copy_state==4)//只有一個人回壘00000001,00000010,00000100
            score++;
        else if(copy_state==3||copy_state==5||copy_state==9||copy_state==6)//兩個人回壘00000011,00000101,00001001(三壘有人全壘打),00000110
            score+=2;
        else if(copy_state==7||copy_state==13||copy_state==11)//三個人回壘00000111,00001101,00001011,
            score+=3;
        else if(copy_state==15)
            score+=4;
        state = state&7;
        // printf("score is %d",score);
        //  printf("state is %d\n",state);
        // printf("test\n");
    }
    printf("%d\n",score);
    printf("%d %d %d\n", state&1, (state>>1)&1, (state>>2)&1);
    return 0;
}

int input(char num)
{
    int ans;
    switch(num)
    {
        case 'O':
            ans=0;
            break;
        case 'H':
            ans=4;
            break;
        case '1':
            ans=1;
            break;
        case '2':
            ans=2;
            break;
        case '3':
            ans=3;
            break;
        default:
            printf(" %d\n",num);
    }
    return ans;
}//這邊有黃色波浪
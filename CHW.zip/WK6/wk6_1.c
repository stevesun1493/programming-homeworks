
/*
15. m分散度

請輸入一個整數m，及一串整數序列。
計算此序列的m分散度，
輸出該m分散度的連續子序列總數，及其所有已排序且不重複的連續子序列，
不需考慮連續子序列總數為零的狀況。

m分散度的連續子序列定義為：
序列中可分成多個長度為m且index連續的子序列，而子序列中的數字要為不重覆數字。

連續子序列排序方式:
子序列以{x, y, z}為例，
以 x 值小到大進行排序，若 x 值相同，以 y 值小到大進行排序，以此類推。

例如：
m = 3，整數序列為 {1, 2, 3, 1, 2, 3, 3}，
可分割成{1, 2, 3}, {2, 3, 1}, {3, 1, 2}, {1, 2, 3}, {2, 3, 3}個index連續的子序列，
而分割後的子序列中的數字為不重複數字的子序列為{1, 2, 3}, {2, 3, 1}, {3, 1, 2}, {1, 2, 3}，
因此 3分散度的連續子序列總數為 4 個，
而輸出依照連續子序列方式後且不重複的連續子序列為:{1, 2, 3}, {2, 3, 1}, {3, 1, 2}。


---------------------------------------------------

輸入說明:
第一行輸入一整數m (3 <= m <= 10)，代表m分散度。
第二行輸入一串長度為 a 的整數序列 ( m <= a <= 20)，數字間以空白字元相隔開，其序列中的整數 b 大小為 0 <= b <= 9。

輸出說明:
第一行輸出該整數序列的m分散度的連續子序列總數。
其後n行，每行輸出已排序後且不重複的一組連續子序列，整數間以空格符號分開輸出。

---------------------------------------------------

範例輸入1：
3
1 2 3 5 4 5 4

範例輸出1：
3
1 2 3
2 3 5
3 5 4

---------------------------------------------------

範例輸入2：
7
7 4 1 8 5 2 9 7 4 1 8 5 2 9 6

範例輸出2：
9
1 8 5 2 9 7 4
2 9 7 4 1 8 5
4 1 8 5 2 9 6
4 1 8 5 2 9 7
5 2 9 7 4 1 8
7 4 1 8 5 2 9
8 5 2 9 7 4 1
9 7 4 1 8 5 2

---------------------------------------------------

範例輸入3：
3
1 2 3 1 2 3 1 2 3 4

範例輸出3：
8
1 2 3
2 3 1
2 3 4
3 1 2

---------------------------------------------------

範例輸入4：
10
1 2 0 3 6 5 4 9 8 7 1 2 0 3 6 5 4 9 8 7

範例輸出4：
11
0 3 6 5 4 9 8 7 1 2
1 2 0 3 6 5 4 9 8 7
2 0 3 6 5 4 9 8 7 1
3 6 5 4 9 8 7 1 2 0
4 9 8 7 1 2 0 3 6 5
5 4 9 8 7 1 2 0 3 6
6 5 4 9 8 7 1 2 0 3
7 1 2 0 3 6 5 4 9 8
8 7 1 2 0 3 6 5 4 9
9 8 7 1 2 0 3 6 5 4

---------------------------------------------------

範例輸入5：
4
0 1 2 3 2 1 4 5 6 5 4 7 8 9 8 7 0

範例輸出5：
8
0 1 2 3
1 4 5 6
2 1 4 5
3 2 1 4
4 7 8 9
5 4 7 8
6 5 4 7
9 8 7 0

---------------------------------------------------

範例輸入6：
3
0 1 2 3 3 2 1 2 3 1 2 6 7 8 7 9

範例輸出6：
10
0 1 2
1 2 3
1 2 6
2 3 1
2 6 7
3 1 2
3 2 1
6 7 8
8 7 9
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void group(char* ,int,char arr[][11] );//問一下arr二維不能用char ** 接


int compare_strings(const void* a, const void* b) 
{
    const char** str_a = (const char**) a;
    const char** str_b = (const char**) b;
    return strcmp(*str_a, *str_b);
}



int main(void)//問資料存取操作有沒有建議怎麼轉換?自己的寫法感覺轉來轉去//用字元陣列然後依值getchar()不取空白值到\n是不是比較快?順便問空白打''還是' '?
{
    int m;
    scanf("%d",&m);
    getchar();
    //char ans_set[]=//[["123"],["234"],["345"]]三維
    char str[100]="";//為啥我宣告str[]="",下面strlen一值會=0(好像是沒給大小給初值""長度變0)問一下那為什麼puts能印出輸入的字串?
    scanf("%[^\n]",str);
    getchar();
    // puts(str);
    int len=strlen(str);
    // printf("the lengh of str is %d\n",len);//test ok長度正確
    len=(len-1)/2+1;
    // printf("the number of input is %d\n",len);
    int set_num=len-m+1;
    // printf("all potential set number is %d",set_num);//ok組數正確
    
    // printf("\n");
    char new_str[100]="";//存輸入的整個字串
    for(int i=0;i<len;i++)
    {
        new_str[i]=str[2*i];//寫成2*i加1難怪變空白
    }
    // puts(new_str);//這個是所有輸入數字的字串無空白ok
    
    char *str_ptr=new_str;
    char ans[18][11]={"","","","","","","","","","","","","","","","","",""};//18個,用來放合法的分組,等一下要拿來照大小排
    // int n=0;
    group(str_ptr, m,ans);//分組
    int total_num=0;//第一行的答案
    for (int i = 0; i < 18; i++) 
        if (strcmp(ans[i],"")!=0)
             total_num++;
    printf("%d\n",total_num);


    for(int i=0;i<17;i++)
    {
        char temp[11]="";
        if (strcmp(ans[i],"")==0)
            break;
        else
        {
            strcpy(temp,ans[i]);
            for (int j=i+1;j<18;j++)
            {
                if(strcmp(ans[j],ans[i])<=0)
                {
                    strcpy(ans[i],ans[j]);
                    strcpy(ans[j],temp);
                    strcpy(temp,ans[i]);
                }
            }
        }
    }
    //test order
    // for (int i = 0; i < 18; i++) 
    //     if (strcmp(ans[i],"")!=0)
    //         puts(ans[i]);
    int end_judge=0;
    for (int i = 0; i < 18; i++)
    {
        end_judge=0;
        if (strcmp(ans[i],"")==0)
            continue;
        else 
            for(int j=0;j<i;j++)
            {
                if(strcmp(ans[i],ans[j])==0)//代表前面print過
                {
                    end_judge=1;
                    break;
                }
            }
        
        if (end_judge==1)
            continue;
        else
        {
            for(int k=0;k<11;k++)
            {
                if(ans[i][k]=='\0')
                {
                    printf("\n");
                    break;
                }
                else
                {
                    printf("%c",ans[i][k]);
                    printf(" "); 
                }

            }
        }
  
    }    

    //問人的
    // char *test=ans[0][0];
    // qsort(test, 11, sizeof(char*), compare_strings);
    // for (int i = 0; i < 18; i++) 
    //     printf("%s\n", test[i]);

    return 0;
}



void group(char* str_ptr,int m,char ans[18][11])//分組,但是不知道要怎麼存合法的組合
{
    char temp[11]="";
    int judge=1;//用來判斷temp有沒有重複字元
    int templen=strlen(str_ptr);
    if(templen<m)//直接寫strlen(str_ptr)<m為什麼會錯?
    {
        // printf("overlen:%d\n",strlen(str_ptr));
        return;
    }
    else
    {
        for(int i=0;i<m;i++)
        {
            temp[i]=*(str_ptr+i);
        }
        for(int i=0;i<m-1;i++)
        {
            for(int j=i+1;j<m;j++)
                if(temp[i]==temp[j])
                {    
                    judge=0;
                    break;//跳出loop1
                }
            if(judge)//1代表temp[i]沒有重複數字,0代表有重複
                continue;
            else
                break;//跳出loop2
        }
        if(judge)
            // puts(temp);//測試分組有沒有分對
            for(int i=0;i<18;i++)
                if (strcmp(ans[i],"")==0)
                {
                    strcpy(ans[i],temp);
                    // puts(ans[i]);//測試分組有沒有分對
                    break;
                }
        str_ptr++;
        // printf("\n");
        group(str_ptr,m,ans);   
    }
}
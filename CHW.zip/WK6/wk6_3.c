/*
17. 數字反序

請輸入一個長度為n的整數數列 A = (a[1], a[2], a[3], ..., a[n] )，
請計算該整數數列的反序總數。

反序的定義為：
如果數列 A 中任意兩個數字 a[i] 和 a[j] ( 0 <= i, j <= n) 滿足 i < j 且 a[i] > a[j]，
則稱 (a[i], a[j]) 是 A 中的一個反序 (inversion)。

定義 W(A) 為 A 中反序數量。
例如，在數列 A = (3, 1, 9, 8, 9, 2)中，共有 (3, 1)、(3, 2)、(9, 8)、(9, 2)、 (8, 2)、(9, 2) 6個反序 ，所以 W(A) = 6。

若要對整數數列進行做檢查，找出所有反序數量 ，
但如果整數數列過長時，計算時間會超過系統的給定時限，
因此需運用以下分而治之(divide and conquer)策略所設計更有效率的方法。

分而治之的策略為：
1. 將A等分為前後兩個數列 X 與 Y，其中 X 的長度是 n/2。
2. 遞迴計算 W(X) 和 W(Y) 。
3. 計算W(A) = W(X) + W(Y) + S(X, Y)，其中 S(X, Y) 是由 X 中的數字與 Y 中的數字構成的反序數量 。

---------------------------------------------------

輸入說明:
第一行輸入一整數m (15 <= m <= 100)，代表整數序列長度。
第二行輸入一串長度為m的整數序列，數字間以空白字元相隔開，其中整數序列的整數b大小為 0 <= b <= 9。

輸出說明:
第一行輸出該組數列反序的總數s。

---------------------------------------------------

範例輸入1：
15
3 1 9 8 9 2 2 7 6 5 4 1 4 3 5

範例輸出1：
57

---------------------------------------------------

範例輸入2：
30
3 1 9 8 9 2 2 7 6 5 4 1 4 3 5 3 1 9 8 9 2 2 7 6 5 4 1 4 3 5

範例輸出2：
213

---------------------------------------------------

範例輸入3：
50
9 7 7 2 4 0 2 2 0 0 0 3 7 8 4 5 0 2 1 6 5 4 2 3 1 3 9 8 8 4 1 4 8 0 8 9 1 3 5 0 9 8 7 2 6 4 9 4 0 3

範例輸出3：
497

---------------------------------------------------

範例輸入4：
80
4 7 6 8 9 0 9 8 7 7 0 7 8 3 6 4 8 6 8 6 3 2 8 1 3 1 2 9 9 2 3 3 3 7 8 0 8 6 3 3 5 6 8 8 3 5 5 4 8 8 2 3 6 9 5 5 8 6 3 3 1 3 9 4 5 5 2 0 3 1 6 1 3 4 8 0 3 4 4 2

範例輸出4：
1687

---------------------------------------------------

範例輸入5：
100
1 6 0 7 5 0 7 1 8 5 2 2 5 4 8 4 5 7 1 4 4 3 9 9 0 8 3 8 1 5 7 1 0 9 6 7 3 0 3 1 2 0 5 3 8 7 7 0 3 1 5 9 2 4 6 2 7 2 1 9 8 0 9 7 6 2 7 3 8 6 1 0 1 8 7 5 2 0 8 0 5 8 6 0 2 0 3 6 3 3 6 1 5 9 3 2 8 2 2 4

範例輸出5：
2291

*/


//google的解法,有遞迴障礙需要解說
// C program to Count
// Inversions in an array
// using Merge Sort
#include <stdio.h>
#include <stdlib.h>


int mergeSort(int arr[], int temp[], int left, int right);
int merge(int arr[], int temp[], int left, int mid,int right);
  
// This function sorts the input array and returns the
// number of inversions in the array

  
// An auxiliary recursive function
// that sorts the input
// array and returns the number
// of inversions in the array.
int mergeSort(int arr[], int temp[], int left, int right)//切割
{
    int mid, inverse_num = 0;
    if (right > left)//代表還能被分 
    {
        // Divide the array into two parts and call
        // _mergeSortAndCountInv() for each of the parts
        mid = (right + left) / 2;
  
        // Inversion count will be the sum of inversions in
        // left-part, right-part and number of inversions in
        // merging
        inverse_num += mergeSort(arr, temp, left, mid);
        inverse_num += mergeSort(arr, temp, mid + 1, right);
  
        // Merge the two parts
        inverse_num += merge(arr, temp, left, mid + 1, right);
    }
    return inverse_num;
}
  
// This function merges two sorted
// arrays and returns inversion
// count in the arrays.
int merge(int arr[], int temp[], int left, int mid,int right)//排序
{
    int i, j, k;
    int inverse_num = 0;
  
    i = left;
    j = mid;
    k = left;
    while ((i < mid) && (j <= right)) 
    {
        if (arr[i] <= arr[j]) {//改成=應該是會錯，一樣的不算反序不要換
            temp[k++] = arr[i++];
        }
        else
        {
            temp[k++] = arr[j++];
  
            /*this is tricky -- see above
             * explanation/diagram for merge()*/
            inverse_num = inverse_num + (mid - i);
        }
    }
  
    // Copy the remaining elements of left subarray
    // (if there are any) to temp
    while (i <mid )//arr右半部都塞完了把左半部剩下的塞進去temp
        temp[k++] = arr[i++];
  
    // Copy the remaining elements of right subarray
    // (if there are any) to temp
    while (j <= right)//arr左半部都塞完了把左半部剩下的塞進去temp
        temp[k++] = arr[j++];
  
    // Copy back the merged elements to original array
    for (i = left; i <= right; i++)
        arr[i] = temp[i];
  
    return inverse_num;
}
  
// Driver code
int main(void)
{
    int size;
    scanf("%d",&size);
    int arr[110];
    for (int i=0;i<size;i++)
        scanf("%d",arr+i);
    getchar();
    int test[120] = {0};
    int *temp=test;
    printf("%d", mergeSort(arr,temp,0, size-1));
    
    return 0;
}
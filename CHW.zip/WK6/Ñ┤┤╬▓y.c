/*
16 - 棒球比賽排序

請計算一支球隊依照球員打擊順序，輸出每位球員各別的編號、安打數及打點數。
輸出結果需使用排序法進行排序，以打點數大到小進行排序，
若打點數相同，以安打數大到小進行排序，
若打點數與安打數皆相同，則以編號小到大進行排序。//怎麼排?問助教;自己想法造一個球員編號的int list,跟著換

棒球規則如下：
球場上有四個壘包， 稱為本壘、一、二和三壘。
球員在本壘握球棒打擊的稱「擊球員」 ，在另外三個壘包的稱為「跑壘員」。
當擊球員擊出「安打」時， 擊球員與跑壘員可移動；
「出局」時，跑壘員不動，擊球員離場換下一位。

擊球員打擊情況如下：
安打：以1B, 2B, 3B 和 HR 代表一、二、三和全(四)壘打。
出局：以 FO 表示 Flyball out, GO 表示 Groundball out, 及 SO 代表 Strike out。
打點數：打擊情況為安打時，當下有多少個球員(擊球員和跑壘員)跑回至本壘得分，其打點數就為多少。

簡化版的棒球比賽規則，球員會依據編號依序上場打擊，
第1位擊球員編號為1，接著第2位擊球員編號為2，接著 3, ..., 9位擊球員。
擊球員打出 K 壘安打時，場上球員(擊球員和跑壘員)會前進 K 個壘包。
本壘到一壘，接著二、三壘，最後回到本壘。當球員回到本壘時可得 1分。
總局數只有五局，每一局達三個出局數，壘包須清空(跑壘員都得離開)，並重新開啟新一局。


---------------------------------------------------

輸入說明:
輸入測資共有九行，第一行為球員編號1的打擊狀況，依此類推，
每一行一開始有一個正整數 N (1 <= N <= 9)，代表該球員總共打擊 N 次 ，
同一行後有 N 個字串(均為兩字元)，依序代表每次打擊結果，字串間以空白字元相隔開。

輸出說明:
第一行輸出總得分，
第二行至第十行，輸出排序後球員的編號，安打數及打點數，數字間以空白字元相隔開。

---------------------------------------------------

範例輸入1：
2 FO SO
2 GO GO
2 SO FO
2 GO FO
2 SO GO
2 GO GO
1 FO
1 GO
1 SO

範例輸出1：
0
1 0 0
2 0 0
3 0 0
4 0 0
5 0 0
6 0 0
7 0 0
8 0 0
9 0 0

---------------------------------------------------

範例輸入2：
4 1B SO SO 1B
4 1B FO 1B 1B
4 HR HR HR SO
4 GO 1B 2B FO
4 2B 2B 3B GO
4 3B SO 1B 1B
4 1B FO FO 1B
4 GO 1B SO SO
4 SO 1B 1B GO

範例輸出2：
12
3 3 8
6 3 2
5 3 1
7 2 1
2 3 0
1 2 0
4 2 0
9 2 0
8 1 0


---------------------------------------------------

範例輸入3：
5 1B SO 1B 2B SO
5 1B FO HR 1B 2B
5 1B 2B SO GO 1B
5 SO 2B 1B 2B SO
5 FO 1B HR HR SO
4 HR HR 3B SO
4 1B SO 1B SO
4 HR FO SO 1B
4 2B 3B GO 1B

範例輸出3：
22
6 3 7
5 3 5
2 4 3
4 3 2
8 2 2
1 3 1
3 3 1
7 2 1
9 3 0

---------------------------------------------------

範例輸入4：
4 FO SO 1B HR
4 GO GO 2B 1B
4 2B 1B SO FO
4 3B GO 2B FO
4 1B 1B SO 2B
4 GO HR GO 1B
4 HR FO 3B SO
3 3B GO 1B
3 SO 2B 1B

範例輸出4：
14
6 2 4
1 2 3
4 2 3
5 3 1
2 2 1
7 2 1
8 2 1
3 2 0
9 2 0

---------------------------------------------------

範例輸入5：
6 1B FO 1B 1B 1B SO
5 GO 2B GO 1B 1B
5 SO 2B FO HR 2B
5 GO 2B SO HR 3B
5 SO 1B GO HR 3B
5 1B GO 1B GO 2B
5 1B 3B FO 1B 1B
5 1B 3B GO 1B 1B
5 1B 3B SO 2B 1B

範例輸出5：
23
3 3 6
4 3 4
9 4 3
2 3 3
1 4 2
8 4 2
5 3 2
6 3 1
7 4 0
*/


# include <stdio.h>
# include <stdlib.h>
#include <string.h>
int input(char num);
void helpsort(int arr[],int arr2[],int arr3[]);
void exchange(int hits[],int rbi[],int num[],int i,int j,int *temp_rbi,int *temp_hit,int *temp_num);


int main(void)
{
    int stateA=0,copy_state;
    int bat_time[100];
    int hits[9]={0};//放安打數
    int rbi[9]={0};//放打點
    int player_num[9]={1,2,3,4,5,6,7,8,9};//存打者名稱
    char playerA[9][100][100]={{""}};//給出值是這樣給?
    // char playerB[5][100][100];
    char temp[100]="";//Ateam_all and Bteam_all[[""],[""]]



    //A的
    for(int i=0;i<9;i++)
    {
        scanf("%d",bat_time+i);
        // printf("times=%d\n",bat_time[i]);
        for (int j=0;j<bat_time[i];j++)
        {
            scanf("%s",playerA[i][j]);
        }
        getchar(); //吃\n//沒寫好像也不會幹嗎?再問一次
    }

    int j=0;
    int hit_order=0;
    while(j!=-1)//第J打席
    {
        
        for(int i=0;i<9;i++)//第J打席第i位的成績
        {
            if(strcmp(playerA[i][j],"1B")==0|| strcmp(playerA[i][j],"2B")==0||strcmp(playerA[i][j],"3B")==0\
            ||strcmp(playerA[i][j],"HR")==0||strcmp(playerA[i][j],"FO")==0\
                ||strcmp(playerA[i][j],"GO")==0||strcmp(playerA[i][j],"SO")==0)
            {
                // printf("j=%d\n",j);
                // printf("player%d with %d attemp result is %s\n",i+1,j+1,playerA[i][j]);
                // printf("player%d with %d attemp result is %c\n",i+1,j+1,playerA[i][j][0]);
                temp[hit_order]=playerA[i][j][0];
                // puts(temp[0]);
                hit_order++;
            }
            else
            {
                j=-2;
                break;
            }
        }
        j++;
    }
    // puts(temp);//test打擊字串,ok
    
    // A的情形
    int result;
    int out=0;
    int scoreA=0;
    int innA=0;//最後一出局不要歸零
    for(int i=0;temp[i]!='\0';i++)
    {
        //printf("%c",temp[0][i]);
        result=input(temp[i]);
        // printf("%d",result);//ok
        if (result)/*更新壘包情況,result!=0,沒出局*/
        {
            stateA = (stateA << result) | (1<<(result-1));//問一下1<<-1==右移一格嗎?
            hits[i%9]++;
        }
        else/*用來看友梅三出局*/
        {
            out++;
            if (out==3)
            {
                innA++;//下一局
                if(innA==5)//代表第五局結束，防呆
                    break;
                out=0;//出局歸0
                stateA=0;//三出局壘包歸0
            }
        }
        copy_state=stateA;
        copy_state=(copy_state>>3);//看得多少分
        // printf("copy is %d\n",copy_state);//test
        if (copy_state==1||copy_state==2||copy_state==4)//只有一個人回壘00000001,00000010,00000100   
        {
            scoreA++;
            rbi[i%9]++;
        }
        else if(copy_state==3||copy_state==5||copy_state==9||copy_state==6)//兩個人回壘00000011,00000101,00001001(三壘有人全壘打),00000110
        {
            scoreA+=2;
            rbi[i%9]+=2;
        }
        else if(copy_state==7||copy_state==13||copy_state==11)//三個人回壘00000111,00001101,00001011,
        {
            scoreA+=3;
            rbi[i%9]+=3;
        }
        else if(copy_state==15)
        {
            scoreA+=4;
            rbi[i%9]+=4;
        }
        stateA = stateA&7;
   
    }

    printf("%d\n",scoreA);
    // for(int i=0;i<9;i++)//測安打和打點有沒錯,ok
    // {
    //     printf("no.%d batter hit:%d and rbi:%d\n",i+1,hits[i],rbi[i]);

    // }
    helpsort(hits,rbi,player_num);
     
    for(int i=0;i<9;i++)//測排序後安打和打點有沒錯,ok
    {
        printf("%d %d %d\n",player_num[i],hits[i],rbi[i]);
    }
    return 0;
}

int input(char num)
{
    int ans;
    switch(num)
    {
        case 'S':
        case 'F':
        case 'G':
            ans=0;
            break;
        case 'H':
            ans=4;
            break;
        case '1':
            ans=1;
            break;
        case '2':
            ans=2;
            break;
        case '3':
            ans=3;
            break;
        default:
            printf("Wrong input\n");
    }
    return ans;
}
void exchange(int hits[],int rbi[],int num[],int i,int j,int *temp_rbi,int *temp_hit,int *temp_num)
{
    rbi[i]=rbi[j];//重複的事情最三次有沒有其他寫法?
    rbi[j]=*temp_rbi;
    *temp_rbi=rbi[i];
    hits[i]=hits[j];
    hits[j]=*temp_hit;
    *temp_hit=hits[i];
    num[i]=num[j];
    num[j]=*temp_num;
    *temp_num=num[i];
}

void helpsort(int hits[],int rbi[],int num[] )//先妣打點再比安打,最後比編號,大的先
{
    int temp_hit=0;//這坨好像可以放exchange禮就好?
    int temp_rbi=0;
    int temp_num=0;
    for(int i =0;i<8;i++)//<8因為排完倒數第二個就排完惹//看起來像selection sort
    {
        temp_rbi=rbi[i];
        temp_hit=hits[i];
        temp_num=num[i];
        for(int j=i+1;j<9;j++)//通常寫code這種要不要加括弧比較好看?
            if(rbi[j]>rbi[i])//要換
                exchange(hits,rbi,num,i,j,&temp_rbi,&temp_hit,&temp_num);
                // rbi[i]=rbi[j];//重複的事情最三次有沒有其他寫法?
                // rbi[j]=temp_rbi;
                // temp_rbi=rbi[i];
                // hits[i]=hits[j];
                // hits[j]=temp_hit;
                // temp_hit=hits[i];
                // num[i]=num[j];
                // num[j]=temp_num;
                // temp_num=num[i];
            else if(rbi[j]==rbi[i])//打點一樣
                if(hits[j]>hits[i])
                    exchange(hits,rbi,num,i,j,&temp_rbi,&temp_hit,&temp_num);
                    // rbi[i]=rbi[j];//重複的事情最三次有沒有其他寫法?
                    // rbi[j]=temp_rbi;
                    // temp_rbi=rbi[i];
                    // hits[i]=hits[j];
                    // hits[j]=temp_hit;
                    // temp_hit=hits[i];
                    // num[i]=num[j];
                    // num[j]=temp_num;
                    // temp_num=num[i];
                else if(hits[j]==hits[i])
                    if(num[j]<num[i])
                        exchange(hits,rbi,num,i,j,&temp_rbi,&temp_hit,&temp_num);
                        // rbi[i]=rbi[j];//重複的事情最三次有沒有其他寫法?
                        // rbi[j]=temp_rbi;
                        // temp_rbi=rbi[i];
                        // hits[i]=hits[j];
                        // hits[j]=temp_hit;
                        // temp_hit=hits[i];
                        // num[i]=num[j];
                        // num[j]=temp_num;
                        // temp_num=num[i];
    }
}
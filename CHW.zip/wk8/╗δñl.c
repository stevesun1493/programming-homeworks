# include<stdio.h>//問是不是字串吃比較好?
# include<stdlib.h>
void exchange(int**,int**);
void perform1(int *dice);
void perform2(int *dice);
void perform3(int *dice);
int main(void)
{
    int L[6]={4,1,3,6,2,5},M[6]={4,1,3,6,2,5},R[6]={4,1,3,6,2,5};
    int len;
    int *ptrL=L,*ptrM=M,*ptrR=R;
    char dice_num[10]="";
    char move[10]="";
    scanf("%d",&len);
    getchar();
    for(int i=0;i<len;i++)//ok
    {
        dice_num[i]=getchar();
        getchar();// eat space
        move[i]=getchar();
        getchar();//eat \n
    }


    // puts(dice_num);
    // puts(move);



    for(int i=0;i<len;i++)
    {
        if(dice_num[i]=='L')
        {
            if(move[i]=='M')
                exchange(&ptrL,&ptrM);
            else if(move[i]=='R')
                exchange(&ptrL,&ptrR);
            else if(move[i]=='1')
                perform1(ptrL);
            else if(move[i]=='2')
                perform2(ptrL);
            else if(move[i]=='3')//乾打成[3]...
                perform3(ptrL);
        }
        else if(dice_num[i]=='M')
        {
            if(move[i]=='L')
                exchange(&ptrM,&ptrL);
            else if(move[i]=='R')
            {
                // printf("change\n");
                exchange(&ptrM,&ptrR);
            }
            else if(move[i]=='1')
                perform1(ptrM);
            else if(move[i]=='2')
                perform2(ptrM);
            else if(move[i]=='3')
                perform3(ptrM);
        }
        else if(dice_num[i]=='R')
        {
            if(move[i]=='L')
            {
                exchange(&ptrR,&ptrL);
                // printf("change\n");
            }
            else if(move[i]=='M')
                exchange(&ptrR,&ptrM);
            else if(move[i]=='1')
                perform1(ptrR);
            else if(move[i]=='2')
                perform2(ptrR);
            else if(move[i]=='3')
                perform3(ptrR);
        }
        // printf("%d roll resultis:\n",i+1);
        // printf("left:");
        // for(int j=0;j<6;j++)
        //     printf("%d ",*(ptrL+j));
        // printf("\n");
        // printf("Mid:");
        // for(int j=0;j<6;j++)
        //     printf("%d ",*(ptrM+j));
        // printf("\n");
        // printf("Right:");
        // for(int j=0;j<6;j++)
        //     printf("%d ",*(ptrR+j));
        // printf("\n");
    }
    for(int i=0;i<6;i++)
        printf("%d ",*(ptrL+i));
    printf("\n");
    for(int i=0;i<6;i++)
        printf("%d ",*(ptrM+i));
    printf("\n");
    for(int i=0;i<6;i++)
        printf("%d ",*(ptrR+i));


}



void exchange(int **A, int **B)//要用function交換指標只得方向function參數是不是要用雙指標接?//ok真的可以換神奇
{
    int *temp=*A;
    *A=*B;
    *B=temp;
}


void perform1(int *dice)
{
    int temp0=dice[0],temp1=dice[1],temp2=dice[2],temp3=dice[3];
    dice[3]=temp0;
    dice[0]=temp1;
    dice[1]=temp2;
    dice[2]=temp3;
}
void perform2(int *dice)
{
    int temp1=dice[1],temp3=dice[3],temp4=dice[4],temp5=dice[5];
    dice[5]=temp1;
    dice[4]=temp3;
    dice[1]=temp4;
    dice[3]=temp5;
}

void perform3(int *dice)
{
    int temp1=dice[1],temp3=dice[3],temp4=dice[4],temp5=dice[5];
    dice[4]=temp1;
    dice[5]=temp3;
    dice[3]=temp4;
    dice[1]=temp5;
}
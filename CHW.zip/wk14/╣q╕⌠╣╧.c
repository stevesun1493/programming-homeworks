/*
29. 邏輯電路圖
本題必須使用給定程式碼架構實作，否則將不予計分。

解題時可針對範例的架構程式碼做修改，但需符合以下三點:
1. #define中必須定義函數指標，函數的參數可自行決定
2. 有定義struct，且當中有使用到第一點的define
3. 使用struct的函數指標進行本題的實作


上方為邏輯電路範例圖，
電路輸入為 I1, I2, I3, I4，
設定 A、B、C、D、E、F 六個邏輯閘
電路輸出為 O1, O2, O3

A、B、C、D、E、F 可以被設定成 5 種邏輯閘，分別是
雙輸入單輸出的 AND, OR 與 XOR
以及
單輸入單輸出的 NOT 與 Empty

請設定各個邏輯閘，依照電路輸入印出電路輸出為 0 或 1。

如範例圖所示，
B邏輯閘為單輸入單輸出邏輯閘，因此可被設定成 NOT 或 Empty。
A, C, D, E, F邏輯閘為雙輸入單輸出邏輯閘，因此可被設定成 AND, OR 與 XOR。

程式碼架構之範例如下：
#include
#include
#define GATEVALUE(TYPE) int(*GateValue)(void)
typedef struct _Gate{
GATEVALUE();
}Gate;
int GateGetValue(){return 0;}
typedef struct _GateAnd{
GATEVALUE();
}GateAnd;
int GateAndValue(){return 1;}
void CreateGate(Gate *obj){
obj->GateValue = GateGetValue;
}
void CreateGateAND(GateAnd *obj){
obj->GateValue = GateAndValue;
}
int main(int argc, char *argv[]){
Gate gate;
CreateGate(&gate);
GateAnd and;
CreateGateAND(&and);
printf("Gate = %d, GateAND = %d\n", gate.GateValue(), and.GateValue());
return 0;
}

輸入的邏輯閘種類代號如下：
A：AND Gate
O：OR Gate
X：XOR Gate
N：NOT Gate
E：Empty Gate

--------------------------------------------------------------------------------------------------------------

輸入說明:
第一行依序輸入 I1, I2, I3, I4 為0或1，字元間以逗號相隔開。
第二行依序輸入 A, B, C, D, E, F 邏輯閘的設定，輸入邏輯閘種類代號。

輸出說明:
輸出 O1, O2 及 O3，字元間以逗號相隔開。

--------------------------------------------------------------------------------------------------------------

輸入範例 1：
0,0,0,0
X,N,O,X,A,A

輸出範例 1：
1,1,0

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
1,0,1,1
A,E,A,A,X,O

輸出範例 2：
0,0,1

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
0,0,1,0
X,N,A,O,X,X

輸出範例 3：
1,1,1

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
0,0,1,1
O,E,X,O,O,A

輸出範例 4：
0,1,1

--------------------------------------------------------------------------------------------------------------

輸入範例 5：
1,0,0,1
X,N,X,X,A,X

輸出範例 5：
0,1,0
*/
#include<stdio.h>
#include<stdlib.h>

#define GATEVALUE(TYPE) int(*GateValue)(struct TYPE*);\
int output;

typedef struct Gate_s
{
    GATEVALUE(Gate_s);
}Gate_t;

typedef struct GateAnd_s
{
    GATEVALUE(GateAnd_s);
    int input1;
    int input2;
}GateAnd_t;

typedef struct GateOr_s
{
    GATEVALUE(GateOr_s);
    int input1;
    int input2;
}GateOr_t;

typedef struct GateXor_s
{
    GATEVALUE(GateXor_s);
    int input1;
    int input2;
}GateXor_t;

typedef struct GateNot_s
{
    GATEVALUE(GateNot_s);
    int input1;
}GateNot_t;
typedef struct GateEmp_s
{
    GATEVALUE(GateEmp_s);
    int input1;
}GateEmp_t;
int valueAnd(GateAnd_t* obj);
int valueOr(GateOr_t* obj);
int valueXor(GateXor_t* obj);
int valueNot(GateNot_t* obj);
int valueEmp(GateEmp_t* obj);

void Gate_type1(Gate_t *v[],int,int,int);//雙input
void Gate_type2(Gate_t *v[],int);//單input
int main()
{
    int input[4]={0};
    for(int i=0;i<4;i++)
    {
        scanf("%d",input+i);
        getchar();//沒加會錯,吃到','?
    }
    Gate_t **gates=(Gate_t**)malloc(6*sizeof(Gate_t*));
    
    //問只能很笨的呼叫6次嗎?
    Gate_type1(gates,input[0],input[1],0);//A
    // printf("test output after A is %d\n",gates[0]->output);
    Gate_type2(gates,gates[0]->output);//B
    // printf("test output after B is %d\n",gates[1]->output);
    Gate_type1(gates,gates[0]->output,input[2],2);//C
    // printf("test output after C is %d\n",gates[2]->output);
    Gate_type1(gates,gates[1]->output,gates[2]->output,3);//D
    // printf("test output after D is %d\n",gates[3]->output);
    Gate_type1(gates,gates[2]->output,input[3],4);//E
    // printf("test output after E is %d\n",gates[4]->output);
    Gate_type1(gates,gates[3]->output,gates[4]->output,5);//F
    // printf("test output after F is %d\n",gates[5]->output);
    printf("%d,%d,%d",gates[1]->output,gates[3]->output,gates[5]->output);
 

    for(int i=0;i<6;i++)
        free(gates[i]);
    free(gates);
    return 0;
}

void Gate_type1(Gate_t *gates[],int input1,int input2,int i)//雙input(有沒有辦法用一個function含括兩種?)
{
    char type;
    scanf("%c",&type);
    getchar();
    if(type=='A')
    {
        GateAnd_t* and=(GateAnd_t*)malloc(sizeof(GateAnd_t));
        and->input1=input1;
        and->input2=input2;
        and->GateValue=valueAnd;
        and->output=and->GateValue(and);
        gates[i]=(Gate_t*)and;
    }
    else if (type=='O')
    {
        GateOr_t* or=(GateOr_t*)malloc(sizeof(GateOr_t));
        or->input1=input1;
        or->input2=input2;
        or->GateValue=valueOr;
        or->output=or->GateValue(or);
        gates[i]=(Gate_t*)or;
    }
    else if(type=='X')
    {
        GateXor_t* xor=(GateXor_t*)malloc(sizeof(GateXor_t));
        xor->input1=input1;
        xor->input2=input2;
        xor->GateValue=valueXor;
        xor->output=xor->GateValue(xor);
        gates[i]=(Gate_t*)xor;
    }
}
void Gate_type2(Gate_t *gates[],int input)//單input
{
    char type;
    type=getchar();
    getchar();
    if(type=='N')
    {
        GateNot_t* not=(GateNot_t*)malloc(sizeof(GateNot_t));
        not->input1=input;
        not->GateValue=valueNot;
        not->output=not->GateValue(not);
        gates[1]=(Gate_t*)not;
    }
    else if(type=='E')
    {
        GateEmp_t* empty=(GateEmp_t*)malloc(sizeof(GateEmp_t));
        empty->input1=input;
        empty->GateValue=valueEmp;
        empty->output=empty->GateValue(empty);
        gates[1]=(Gate_t*)empty;
    }
}




int valueAnd(GateAnd_t* obj)
{
    return obj->input1&obj->input2;
}
int valueOr(GateOr_t* obj)
{
    return obj->input1|obj->input2;
}

int valueXor(GateXor_t* obj)
{
    return obj->input1^obj->input2;
}

int valueNot(GateNot_t* obj)
{
    // return ~(obj->input1);  ~0=-1?
    if(obj->input1==0)
        return 1;
    else 
        return 0;
}
int valueEmp(GateEmp_t* obj)
{
    return obj->input1;
}
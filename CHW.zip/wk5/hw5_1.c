/*
13. 電路模擬II

模擬一個數位IC，內有回饋電路與紀錄器電路。
輸入N 是二進位 10 位元，輸出是二進位 14 位元。
輸入範圍從 0000000000到 1111111111 (十進位 0~1024)

數位IC內有一個回饋電路,回饋方式:
C(N) = N 當 N(十進位) 為 0 或 N為 1 時
C(N) = C(N/2) 當 N(十進位) 為偶數
C(N) = C((N+1)/2) 當 N(十進位) 為奇數

數位IC內有一個紀錄器 R，會記錄回饋電路的回饋次數。
R(N) = [C(N) 的回饋次數]。例如 N=00001010 (十進位 10)，
即 C(10)= C(5)=C(3)=C(2)=C(1)=1，則 R(10) = 4，共回饋 4 次。

此電路另有一個紀錄器 T，會加總所跑過的0~N次電路回饋次數，
即 T(N) = R(0) + R(1) +...+ R(N)。
以二進位制輸出所有回饋次數加總後的結果。
例如 T(10) = R(0)+R(1)+R(2)+R(3)+R(4)+...+R(10) = 00000000011001(十進位為 25)。

當輸入為 -1時，則結束執行。

例如：
0000000011
-1

輸出為：
00000000000011

---------------------------------------------------

輸入說明:
第一行輸入第一個測試案例資料(二進位 10 bit)
第二行輸入第二個測試案例資料(二進位 10 bit)
....
最後 -1 結束

輸出說明:
每一行輸出一個測試案例資料的結果(二進位 14 bit)。

---------------------------------------------------

輸入範例 1：
0000000000
1111111111
1010101010
-1

輸出範例 1：
00000000000000
10001111110111
01011010100101

---------------------------------------------------

輸入範例 2：
1011101110
1010010110
0111111110
0110101010
-1

輸出範例 2：
01100101001101
01010111011101
00111111101111
00110011111011

---------------------------------------------------

輸入範例 3：
1010101010
0101010101
1011001101
1100100110
1011101010
-1

輸出範例 3：
01011010100101
00100111111110
01100000000011
01101101111101
01100100100101
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int trans_num(char*, int);
int feedback(int,int);
void trans_digit(int);
int main(void)
{
    
    while(1)
    {
    int input_num,feedbacktimes=0,ans=0;//要規0的變數會宣告在外面跑完歸0還是每一次迴圈宣告一次初值給0?
    
    int num_len;
    char input[100]="";
    scanf("%s",input);//想問能不能不要吃字串直接吃2進位的數字這樣直接做bitwise就好
    getchar();//吃/n
    if(input[0]=='-'&&input[1]=='1')
        return 0;
    num_len=strlen(input);
    // printf("len is  %d\n",num_len);//test輸入長度
    input_num=trans_num(input,num_len);
    // printf("the str turn into number is %d\n",input_num);//test轉換成10進位的數字
    feedbacktimes=feedback(input_num,feedbacktimes);
    // printf("feedbacktime is %d\n",feedbacktimes);

    for(int i=0;i<=input_num;i++)
    {
        int temp=0;
        ans+=feedback(i,temp);
        // printf("test ans= %d\n",ans);
    }
    // printf("T(N) ans is %d\n",ans);//ok test T(N)

    trans_digit(ans);
    }
}


int trans_num(char* str, int len)//用str[]接可以嗎?意思一樣?
{
    int num=0;
    // printf("over indextest %d\n",*(str+len));
    // for(int i=0;i<len;i++)//test吃進來的字串
    // {
    //     printf("str for %d index is %c\n",i,*(str+i));
    // }
    for(int i=len-1;i>=0;i--)
    {
        num+=pow(2,i)*(*(str+len-i-1)-'0');//num+=pow(2,i)*(str[len-i-1]-'0')用陣列也會對ㄟ，通常會用哪個?
        // printf("num for %d index is %d\n",len-i-1,num);
    }
    return num;
}

int feedback(int num,int times)
{
    if(num==1||num==0)
        return times;
    else if(num%2==0)
        feedback(num/2,++times);
    else
        feedback((num+1)/2,++times);
}

void trans_digit(int num)
{
    int digit[14];
    for(int i=0;i<14;i++)
    {    
        digit[i]=num%2; 
        num/=2;
    }
    for(int i=13;i>=0;i--)
        printf("%d",digit[i]);
    
    printf("\n");

}

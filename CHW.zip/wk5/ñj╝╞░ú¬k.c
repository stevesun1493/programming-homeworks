/*
14. 大數除法

題目會給予兩個20~40位數(包含上下限)的長正整數做運算，
請根據大數除法計算並輸出商數與餘數。

兩數相除滿足此等式: a = kq + r，
a代表被除數，k代表非零除數，
其中q為商數且必為整數，而r為餘數，且必為自然數，滿足 0 <= r < |k|

---------------------------------------------------

輸入說明：
第一行輸入第一個長正整數 a (20 <= strlen(a) <= 40)，代表被除數
第二行輸入第二個長正整數 k (20 <= strlen(k) <= 40)，代表非零除數

輸出說明：
第一行輸出大數除法計算後的商數結果
第二行輸出大數除法計算後的餘數結果

---------------------------------------------------

輸入範例 1：
9999999999999999999999999999999999999999
3333333333333333333333333333333333333333

輸出範例 1：
3
0

---------------------------------------------------

輸入範例 2：
6322083025804530270923509282757380346975
1264416605160906054184701856551476069395

輸出範例 2：
5
0

---------------------------------------------------

輸入範例 3：
8487528979174018417498589236759279346745
1912490723489072389729385792835792371975

輸出範例 3：
4
837566085217728858581046065416109858845

---------------------------------------------------

輸入範例 4：
33812904847198749749167264659729735712
2989890771728947948719728947461452

輸出範例 4：
11309
230109716077397095849992888175044

---------------------------------------------------

輸入範例 5：
3249872592333552350955555576
41137627751057624695639944

輸出範例 5：
79
0

---------------------------------------------------

輸入範例 6：
16456334222835609053166331289
16453043605131221

輸出範例 6：
1000200000546
564684623

---------------------------------------------------

輸入範例 7：
90000001421400000002000013300
12000124000045600005

輸出範例 7：
7499922619
2653247493074000205

---------------------------------------------------

輸入範例 8：
9000000124000000460000000002400056000003
302113000000053000070070070200002040

輸出範例 8：
29790
53853998421587912612611141995228403

---------------------------------------------------

輸入範例 9：
1543031303431638460345211301334064
1543031303431638460345211301334069

輸出範例 9：
0
1543031303431638460345211301334064



*/


#include <stdio.h>
#include<stdlib.h>
#include<string.h>

void transfer(char*,int*);
void minus(int numA[],int lenA,int numB[],int lenB);
int judge(int arr[],int arr2[]);
void add(int arr[]);

int main(void)
{
    char strA[50]="",strB[50]="";
    int num_a[50]={0},num_b[50]={0},lenA,lenB, ans[50]={0};

    scanf("%s",strA);
    getchar();
    scanf("%s",strB);
    getchar();
    lenA=strlen(strA);
    lenB=strlen(strB);


    if (strcmp(strA,strB)==0)//表示輸入數字一樣
        printf("1\n0");
    else if((lenA-lenB)>=8)
    {
        int temp[50]={0};//放每一次要被減的數字,反序
        int dif_len=lenA-lenB;//需要補得0樹木
        int real_ans[50]={0};//正序
        int time=0;//看減了幾次
        transfer(strA,num_a);
        transfer(strB,num_b);
        for(int i=0;i<=lenA-lenB;i++)//最多要跑這麼多次(1~lenA-lenB+1位數)
        {
            for(int j=0;j<lenB;j++)//計得跑完要清空(全部填0)//temp每次少一個0
                temp[dif_len+j]=num_b[j];
            while(judge(num_a,temp)!=0)
            {
                minus(num_a,lenA,temp,lenB);
                time++;
            }
            real_ans[i]=time;
            dif_len--;//下一輪少一個0
            time=0;//數字歸0
            for (int r=0;r<50;r++)
                 temp[r]=0;//temp也清空

        }
        //test
        for(int k=0;k<lenA-lenB+1;k++)//0417 發現判斷其實有誤,還是要先找第幾個數開始不為0
            if(k==0&&real_ans[k]==0)
                continue;//第一位數為0不要印
            else
                printf("%d",real_ans[k]);
        printf("\n");
        //下面印餘數直接複製最下面的
        int index;//判斷餘數從哪開始印
        for(int i=lenA-1;i>=0;i--)//最後一位開始找
            if(num_a[i]!=0)
            {
                index=i;//即後面數來第ans[index]!=0
                break;    
            }
            else
                index=-1;//陣列全部為0代表被整除餘數為0
        if (index==-1)
            printf("0");
        else
            for(int i =index;i>=0;i--)
                printf("%d",num_a[i]);


    }
    else//除數!=被除數
    {
        transfer(strA,num_a);
        transfer(strB,num_b);
        while(judge(num_a,num_b)!=0)//除數比被除數大
        {
            minus(num_a,lenA,num_b,lenB);
            add(ans);
        }

        int numstart;//判斷商數從哪個index開始印
        for (int i=49;i>=0;i--)
            if(ans[i]!=0)
            {
                numstart=i;
                break;
            }
            else
                numstart=-1;//代表商數為0
        if(numstart==-1)
            printf("0");
        else
            for(int i =numstart;i>=0;i--)
                printf("%d",ans[i]);
        printf("\n");
        

        int index;//判斷餘數從哪開始印
        for(int i=lenA-1;i>=0;i--)//最後一位開始找
            if(num_a[i]!=0)
            {
                index=i;//即後面數來第ans[index]!=0
                break;    
            }
            else
                index=-1;//陣列全部為0代表被整除餘數為0
        if (index==-1)
            printf("0");
        else
            for(int i =index;i>=0;i--)
                printf("%d",num_a[i]);
    }
}



void transfer(char* str,int* num)
{
    int len=strlen(str);
    // printf("input lengh is:%d\n",len);
    for(int i=len-1;i>=0;i--)
    {
        num[len-1-i]=str[i]-'0';
    }
}


void minus(int numA[],int lenA,int numB[],int lenB)
{
    int carry=0;
    int len=lenA>lenB?lenA:lenB;

    for(int i=0;i<=len-1;i++)  
        if((numA[i]-carry)>=numB[i])//不用跟前面借數字
        { 
            numA[i]=numA[i]-carry-numB[i];
            carry=0;
        }
        else if((numA[i]-carry)<numB[i])
        {
            numA[i]=numA[i]-carry+10-numB[i];//+10跟前面借一位
            carry=1;
        }
}


void add(int ans[])
{
    int carry=1;
    for(int i=0;i<50;i++)
    {
        ans[i]=ans[i]+carry;
        if (ans[i]>=10)
            ans[i]-=10;
        else
            break;//不用進位了
    }

}


int judge(int numA[],int numB[])//判斷兩個數字誰比較大
{
    for(int i=49;i>=0;i--)
        if (numA[i]>numB[i])
        {    
            return 1;
        }
        else if (numA[i]<numB[i])
        {
            // printf("b is now larger over\n");
            return 0;
        }
    return 1;//代表兩數完全一樣要繼續減
}

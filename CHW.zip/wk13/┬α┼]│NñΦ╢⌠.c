/*
28. 魔術方塊

有一魔術方塊有六面，一開始白色朝自己，藍色朝上，紅色朝右
立體示意圖如連結所示，

展開示意圖如連結所示，


經過 M 次操作後，輸出魔術方塊朝上9格的顏色編號。

顏色編號，1: 藍色，2: 紅色，3: 黃色，4: 白色，5: 橘色，6:綠色。

魔術方塊的操作：
10 表示直欄(column)最左邊向前轉一次。
11 表示直欄(column)中間向前轉一次。
12 表示直欄(column)最右邊向前轉一次。
20 表示橫列(row)最上面向左轉一次。
21 表示橫列(row)中間向左轉一次。
22 表示橫列(row)最下面向左轉一次。
註：以上修改操作，皆不會轉動魔術方塊的本體，只會針對欄或列做操作

範例說明：
3 接下來會有3次修改操作
10 表示直欄(column)最左邊向前轉一次
20 表示橫列(row)最上面向左轉一次
10 表示直欄(column)最左邊向前轉一次

一開始，魔術方塊的初始狀態示意圖 ，


經過10操作後魔術方塊的狀態示意圖，


經過20操作後魔術方塊的狀態示意圖，


經過10操作後魔術方塊的狀態示意圖 ，


最後得到魔術方塊朝上9格的顏色編號，分別為
2 4 4
6 1 1
6 1 1

--------------------------------------------------------------------------------------------------------------

輸入說明：
第一行，輸入一整數 M，代表魔術方塊的操作次數，
其後 M 行，每一行輸入一整數，代表魔術方塊的操作方式。

輸出說明：
經過M次操作後，輸出朝上9格的顏色編號。
註：row的數字間以一個空格區隔

--------------------------------------------------------------------------------------------------------------

範例輸入 1：
1
10

範例輸出 1：
4 1 1
4 1 1
4 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 2：
1
21

範例輸出 2：
1 1 1
1 1 1
1 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 3：
2
10
12

範例輸出 3：
4 1 4
4 1 4
4 1 4

--------------------------------------------------------------------------------------------------------------

範例輸入 4：
2
10
20

範例輸出 4：
4 4 4
1 1 1
1 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 5：
2
20
10

範例輸出 5：
2 1 1
4 1 1
4 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 6：
2
21
22

範例輸出 6：
1 1 1
1 1 1
1 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 7：
3
12
12
12

範例輸出 7：
1 1 3
1 1 3
1 1 3

--------------------------------------------------------------------------------------------------------------

範例輸入 8：
3
10
12
20

範例輸出 8：
4 4 4
1 1 1
4 4 4

--------------------------------------------------------------------------------------------------------------

範例輸入 9：
3
10
20
12

範例輸出 9：
4 4 2
1 1 4
1 1 4

--------------------------------------------------------------------------------------------------------------

範例輸入 10：
3
20
12
10

範例輸出 10：
2 1 2
4 1 4
4 1 4

--------------------------------------------------------------------------------------------------------------

範例輸入 11：
3
20
22
10

範例輸出 11：
2 1 1
4 1 1
2 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 12：
3
20
12
22

範例輸出 12：
1 1 2
1 1 4
1 1 4

--------------------------------------------------------------------------------------------------------------

範例輸入 13：
3
10
22
20

範例輸出 13：
4 4 4
1 1 1
1 1 1

--------------------------------------------------------------------------------------------------------------

範例輸入 14：
3
21
22
20

範例輸出 14：
1 1 1
1 1 1
1 1 1


魔術方塊的操作：
10 表示直欄(column)最左邊向前轉一次。
11 表示直欄(column)中間向前轉一次。
12 表示直欄(column)最右邊向前轉一次。
20 表示橫列(row)最上面向左轉一次。
21 表示橫列(row)中間向左轉一次。
22 表示橫列(row)最下面向左轉一次。
// 顏色編號，1: 藍色，2: 紅色，3: 黃色，4: 白色，5: 橘色，6:綠色
*/
#include<stdio.h>
#include<stdlib.h>





typedef struct  struc_s
{
    int roll;
    void (*func_ptr) (int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3]);
}struc_t;


void choose(struc_t*);
void run_10(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);//可以不寫3嗎?no
void run_11(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);
void run_12(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);
void run_20(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);
void run_21(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);
void run_22(int (*)[3],int (*)[3],int (*)[3],int (*)[3],int(*)[3],int (*)[3]);

void counter_clock(int (*)[3]);//忘記寫
void clockwise(int (*)[3]);
void give_value(int *gived,int give);
int main()
{
    int up[3][3]={1,1,1,1,1,1,1,1,1},down[3][3]={6,6,6,6,6,6,6,6,6},left[3][3]={5,5,5,5,5,5,5,5,5},\
        right[3][3]={2,2,2,2,2,2,2,2,2},front[3][3]={4,4,4,4,4,4,4,4,4},back[3][3]={3,3,3,3,3,3,3,3,3};

    int roll_num;
    scanf("%d",&roll_num);
    struc_t data;
    // void (*run)(int (*arr)[],int (*arr2)[],int (*arr3)[],int (*arr4)[]);
    for(int i=0;i<roll_num;i++)
    {
        scanf("%d",&data.roll);
        choose(&data);
        data.func_ptr(up,down,left,right,front,back);

    }
    for(int k=0;k<3;k++)
    {
        for(int j=0;j<3;j++)
            printf("%d ",*(*(up+k)+j));
        printf("\n");
    }
    return 0;
}




void choose(struc_t *data)//可以用switch的樣子
{
    if(data->roll==10)
    {
        data->func_ptr=run_10;
    }
    else if(data->roll==11)
    {
        data->func_ptr=run_11;
    }
    else if(data->roll==12)
    {
        data->func_ptr=run_12;
    }
    else if(data->roll==20)
    {
        data->func_ptr=run_20;
    }
    else if(data->roll==21)
    {
        data->func_ptr=run_21;
    }
    else if(data->roll==22)
    {
        data->func_ptr=run_22;
    }
}



void run_10(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])//ok
{
    // printf("enter 10\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,up[i][0]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,back[i][0]);
    
    for(int i=0;i<3;i++)
        give_value(*(back+i),*(temp1+i));//up轉給back
    for(int i=0;i<3;i++)
         give_value(temp1+i,down[i][0]);//temp1存down
    for(int i=0;i<3;i++)
        give_value(*(down+i),*(temp2+i));//back轉給bottom
    for(int i=0;i<3;i++)
        give_value(temp2+i,front[i][0]);//temp2存front;
    for(int i=0;i<3;i++)
        give_value(*(front+i),*(temp1+i));//down轉給front
    for(int i=0;i<3;i++)
        give_value(*(up+i),*(temp2+i));//back轉給bottom 
    counter_clock(left);//ans
 
}
void run_11(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])
{
    // printf("enter 11\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,up[i][1]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,back[i][1]);
    
    for(int i=0;i<3;i++)
        give_value(*(back+i)+1,*(temp1+i));//up轉給back
    for(int i=0;i<3;i++)
         give_value(temp1+i,down[i][1]);//temp1存down
    for(int i=0;i<3;i++)
        give_value(*(down+i)+1,*(temp2+i));//back轉給bottom
    for(int i=0;i<3;i++)
        give_value(temp2+i,front[i][1]);//temp2存front;
    for(int i=0;i<3;i++)
        give_value(*(front+i)+1,*(temp1+i));//down轉給front
    for(int i=0;i<3;i++)
        give_value(*(up+i)+1,*(temp2+i));//back轉給bottom 
    
}

void run_12(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])
{
    // printf("enter 12\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,up[i][2]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,back[i][2]);
    
    for(int i=0;i<3;i++)
        give_value(*(back+i)+2,*(temp1+i));//up轉給back
    for(int i=0;i<3;i++)
         give_value(temp1+i,down[i][2]);//temp1存down////ans 2
    for(int i=0;i<3;i++)
        give_value(*(down+i)+2,*(temp2+i));//back轉給bottom
    for(int i=0;i<3;i++)
        give_value(temp2+i,front[i][2]);//temp2存front;
    for(int i=0;i<3;i++)
        give_value(*(front+i)+2,*(temp1+i));//down轉給front
    for(int i=0;i<3;i++)
        give_value(*(up+i)+2,*(temp2+i));//back轉給bottom 
    clockwise(right);//ans
}

void run_20(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])//ok
{
    // printf("enter 20\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,front[0][i]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,left[0][i]);
    
    for(int i=0;i<3;i++)
        give_value(*(left)+i,*(temp1+i));//front轉給left
    for(int i=0;i<3;i++)
        give_value(temp1+i,back[0][i]);//temp1存back
    for(int i=0;i<3;i++)
        give_value(*(back)+i,*(temp2+i));//left轉給back
    for(int i=0;i<3;i++)
        give_value(temp2+i,right[0][i]);//temp2存right;
    for(int i=0;i<3;i++)
        give_value(*(right)+i,*(temp1+i));//back轉給right
    for(int i=0;i<3;i++)
        give_value(*(front)+i,*(temp2+i));//right轉給front 
    clockwise(up);
}

void run_21(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])//ok
{
    // printf("enter 21\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,front[1][i]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,left[1][i]);
    
    for(int i=0;i<3;i++)
        give_value(*(left+1)+i,*(temp1+i));//front轉給left
    for(int i=0;i<3;i++)
        give_value(temp1+i,back[1][i]);//temp1存back
    for(int i=0;i<3;i++)
        give_value(*(back+1)+i,*(temp2+i));//left轉給back
    for(int i=0;i<3;i++)
        give_value(temp2+i,right[1][i]);//temp2存right;
    for(int i=0;i<3;i++)
        give_value(*(right+1)+i,*(temp1+i));//back轉給right
    for(int i=0;i<3;i++)
        give_value(*(front+1)+i,*(temp2+i));//right轉給front 
}
void run_22(int (*up)[3],int (*down)[3],int (*left)[3],int (*right)[3],int(*front)[3],int (*back)[3])//ok
{
    // printf("enter 22\n");
    int temp1[3]={0};
    int temp2[3]={0};
    for(int i=0;i<3;i++)
        give_value(temp1+i,front[2][i]);
    
    for(int i=0;i<3;i++)
        give_value(temp2+i,left[2][i]);
    
    for(int i=0;i<3;i++)
        give_value(*(left+2)+i,*(temp1+i));//front轉給left
    for(int i=0;i<3;i++)
        give_value(temp1+i,back[2][i]);//temp1存back
    for(int i=0;i<3;i++)
        give_value(*(back+2)+i,*(temp2+i));//left轉給back
    for(int i=0;i<3;i++)
        give_value(temp2+i,right[2][i]);//temp2存right;
    for(int i=0;i<3;i++)
        give_value(*(right+2)+i,*(temp1+i));//back轉給right
    for(int i=0;i<3;i++)
        give_value(*(front+2)+i,*(temp2+i));//right轉給front 
    counter_clock(down);
}

void give_value(int *gived,int give)//右邊值給左邊地址的值
{
    *gived=give;
}

void clockwise(int (*arr)[3])
{
    int temp1[3]={0};
    int temp2[3]={0};
    int temp3[3]={0};
    for(int i=0;i<3;i++)
    {
        give_value(temp1+i,**(arr+2-i));
        give_value(temp2+i,*(*(arr+2-i)+1));
        give_value(temp3+i,*(*(arr+2-i)+2));
    }
    for(int i=0;i<3;i++)
    {
        give_value(*(arr)+i,*(temp1+i));
        give_value(*(arr+1)+i,*(temp2+i));
        give_value(*(arr+2)+i,*(temp3+i));  
    }
}


void counter_clock(int (*arr)[3])
{
    int temp1[3]={0};
    int temp2[3]={0};
    int temp3[3]={0};
    for(int i=0;i<3;i++)
    {
        give_value(temp1+i,*(*(arr+i)+2));
        give_value(temp2+i,*(*(arr+i)+1));
        give_value(temp3+i,**(arr+i));
    }
    for(int i=0;i<3;i++)
    {
        give_value(*(arr)+i,*(temp1+i));
        give_value(*(arr+1)+i,*(temp2+i));
        give_value(*(arr+2)+i,*(temp3+i));  
    }
}


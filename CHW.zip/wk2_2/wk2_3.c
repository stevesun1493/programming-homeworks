/*
題目7 - 複合圖案

請使用迴圈 (while loop 或 for loop)
根據圖案編號 N 與圖案高度 M ，輸出對應圖案。

以下為圖案編號與其圖案規則：

圖案編號N = 1時，英文字母與星號的複合圖案。
第一層為 M - 1個井字號 及 1 個星號 及 M - 1個井字號，
第二層開始中間為英文字母與星號相間，兩側為 M - 2個井字號，
而每一層的英文字母會以A、B、C作循環。規則如下:
第二層的輸出英文字母為 A，
第三層的輸出英文字母為 B，
第四層的輸出英文字母為 C，
第五層的輸出英文字母回到A，以此類推循環至 M 行，
範例:N = 1, M = 5，輸出圖案為：
####*####
###*A*###
##*B*B*##
#*C*C*C*#
*A*A*A*A*

( 圖例: https://i.imgur.com/W4o4YtB.png )

圖案編號N = 2時，數字與星號的複合圖案。
第一行為 數字 1 及 M * 2 個星號 及 數字 1 。
第二行為 數字 1 到 2 及 (M - 1)*2 個星號 及 數字 2 到 1。
第三行為 數字 1 到 3 及 (M - 2)*2 個星號 及 數字 3 到 1。
數字的範圍和星號的數量，依照規則以層數以此類推，直到M行結束。
範例:N = 2, M = 5 ，輸出圖案為：
1**********1
12********21
123******321
1234****4321
12345**54321


--------------------------------------------------

輸入說明:

輸入兩個整數 N, M，
第一行輸入整數 N (1 <= N <= 2)， 代表圖案編號，
第二行輸入整數 M (2 <= M <= 9)，代表圖案高度。

輸出說明:
按照圖案編號輸出對應圖案，
若圖案編號 N 或圖案高度 M 超出範圍，則輸出 error

-------------------------------------------------------------

範例輸入1：
3
5


範例輸出1：
error

-------------------------------------------------------------

範例輸入2：
1
1


範例輸出2：
error

-------------------------------------------------------------

範例輸入3：
2
10


範例輸出3：
error

-------------------------------------------------------------

範例輸入4：
1
9


範例輸出4：
########*########
#######*A*#######
######*B*B*######
#####*C*C*C*#####
####*A*A*A*A*####
###*B*B*B*B*B*###
##*C*C*C*C*C*C*##
#*A*A*A*A*A*A*A*#
*B*B*B*B*B*B*B*B*


( 圖例: https://i.imgur.com/y6eX8Xz.png )

-------------------------------------------------------------

範例輸入5：
2
9


範例輸出5：
1******************1
12****************21
123**************321
1234************4321
12345**********54321
123456********654321
1234567******7654321
12345678****87654321
123456789**987654321
*/
# include<stdlib.h>
# include<stdio.h>
# define TYPE1 1
# define TYPE2 2//define感覺很常用

void input(void);
void display(int);
void display(int);
// void display2(int);

int main(void)
{
    input();
    return 0;
}

void input(void)
{
    int level;
    int type;
    scanf("%d",&type);
    getchar();//吃'\n'
    // printf("%c\n",type);
    if(type!=TYPE1&&type!=TYPE2)
    {
        getchar();//吃兩個數字再error
        printf("error");
    }
    else if (type==TYPE1)
    {
        scanf("%d",&level);
        getchar();
        if (level<2||level>9)
            printf("error");
        else 
        {   
            //printf("TYPE1 level is %d\n",level);
            display(level);
        }

    }
    else if (type==TYPE2)
    {
        scanf("%d",&level);
        getchar();
        if (level<2||level>9)
            printf("error");
        else 
        {
            //printf("TYPE2 level is %d\n",level);
        display2(level);
        }
    }
}

void display(int level)
{
    int i;
    for(i=level;i>0;i--)
    {
        for(int j=(i-1);j>0;j--)
            printf("#");

        for(int j=0;j<level-i;j++)
        {
            printf("*");
            int type_char=(level-i)%3;
            if (type_char==1)
                printf("A");
            else if(type_char==2)
                printf("B");
            else if(type_char==0)
                printf("C");
        }
        printf("*");
        for(int j=(i-1);j>0;j--)
            printf("#");

        printf("\n");
    }
}



void display2(int level)
{
    
    for(int i=0;i<level;i++)
    {
        for(int j=1;j<i+2;j++)
            printf("%d",j);
        
        
        for(int j=level;j-i>0;j--)
        {
            printf("*");
            printf("*");
        }
        for(int j=i+1;j>0;j--)
            printf("%d",j);
        printf("\n");
    }
}
/*
題目5 - 有限狀態機

請使用有限狀態機判斷輸入值為以下何種型態:
1. 變數
2. 整數
3. 浮點數
4. 真分數
5. 代分數

變數規則:
變數需符合以下命名法則:
1. 必須由 "大(小)寫英文字母" 或 "數字" 或  "_"  組成
2. 必須以 "大(小)寫英文字母" 或是  "_"  開頭


整數規則:
整數必須所有字元皆為數字，且開頭不可為 0，但整數為 0 的狀況例外，且不為負數。


浮點數規則:
浮點數除了小數點，所有字元皆為數字，且不為負數。
開頭不可為小數點，結尾也不可為小數點，小數點最多只有一個，
開頭若為0，最多一個。


真分數規則:
分子分母以斜線符號"/"隔開，斜線前為分子，斜線後為分母，
分子必須小於分母，分子分母皆為數字，數字不以0開頭，且皆不為負數。


代分數規則:
整數部分與分數部分以小括號隔開，小括號前為整數部分，小括號內為分數部分，
分子分母以斜線符號"/"隔開，斜線前為分子，斜線後為分母，分子必須小於分母，
整數、分子與分母皆為數字，數字不以0開頭，且皆不為負數，分母不得為0。


---------------------------------------------------

輸入說明:
第一行為一整數N (1 <= N <= 7)，代表有多少次的字串輸入。
其後 N 行為輸入一字串，其長度為1~20字元。

輸出說明:
依據輸入字串，輸出對應值，
若字串為變數，輸出variable
若字串為整數，輸出integer
若字串為浮點數，輸出float，且其後兩行分別輸出整數部分與小數部分
若字串為真分數，輸出proper fraction
若字串為代分數，輸出algebraic fraction
若以上情況皆不符合，輸出error

---------------------------------------------------

範例輸入1：
4
_CisEZ_EMZ
CodeBlock
_1_0_1_1_0
TestP2P__


範例輸出1：
variable
variable
variable
variable

---------------------------------------------------

範例輸入2：
7
9874437434
5920
68729952826
0
1634644357
11155577788
6637373


範例輸出2：
integer
integer
integer
integer
integer
integer
integer

---------------------------------------------------

範例輸入3：
4
3.14159265358979323
1454864.720404254
1414.7414
987654154.0


範例輸出3：
float
3 
14159265358979323
float
1454864 
720404254
float
1414 
7414
float
987654154
0

---------------------------------------------------

範例輸入4：
4
123456789/987654321
84683434/563435861
99999/999999
1/2


範例輸出4：
proper fraction
proper fraction
proper fraction
proper fraction

---------------------------------------------------

範例輸入5：
3
888(6666/7777)
9(3/5)
24(435/7965)


範例輸出5：
algebraic fraction
algebraic fraction
algebraic fraction

---------------------------------------------------

範例輸入6：
7
s35!@567-8!67*
63573468/
357346.
64435/7965)
1(374644363)
987()
1.234.75


範例輸出6：
error
error
error
error
error
error
error


---------------------------------------------------

範例輸入7：
7
_abc
456
10.654
75/996
3(4/5)
5(6//7)
10000/11


範例輸出6：
variable
integer
float
10
654
proper fraction
algebraic fraction
error
error
*/

# include<stdio.h>
# include<stdlib.h>
# include <ctype.h>

# define START 0
# define VA 1//variable
# define VA_END 2//確定是變數結束

# define INT 3//整數
# define ZEROCHECK 4//看是不是整數0
# define ZERO 5//確定是整數0
# define INT_END 6//確定是整數結束

# define FLOATP 7//遇到點可能是小數
# define FLOAT 8
# define FLOAT_END 9//確定是小數結束

# define PRO_FRAP 10
# define PRO_FRA 11
# define PRO_FRA_END 12

# define ALG_FRAP 13
# define ALG_FRA 14
# define ALG_FRA_2P 15
# define ALG_FRA_2 16
# define ALG_FRA_2ENDP 17
# define ALG_FRA_2END 18

# define ERROR 100//確定錯誤

int checkInput(void);
int judge_state(int,char);

int main(void)
{
    int num_times;
    scanf("%d",&num_times);
    // fflush(stdin);//不行就用下面
    getchar();
    for(int i=0;i<num_times;i++)
    {
        int final_state=checkInput();
        if(final_state==100)
            printf("error\n");
    }
    return 0;
}

int checkInput(void)
{
    char key;
    int i=0;//看整數是不是第一個位數(因為對不同位數字元的處理不同)
    int state=START;
    int int_sum=0;
    int float_count=0;//判斷key值是小數點第幾位
    long long int float_sum=0;//eo4數字也太大

    while(1)
    {
        key=getchar();
        state=judge_state(state,key);
        if(state==VA_END)
        {
            printf("variable\n");
            return state;
        }
        else if (state==ZERO)
        {
            printf("integer\n");
            break;
        }

        else if (state==ZEROCHECK)
        {
            int_sum+=0;
        }
        else if (state==INT)
        {
            if (i++==0)
                int_sum=key-'0';
            else
            {
                int_sum=int_sum*10+(key-'0');
                // printf("%d digit\n",i);//test整數位數
                // printf("%d total\n",int_sum);
            }
        }






        else if (state==INT_END)
        {
            printf("integer\n");
            break;
        }
        




        else if(state==FLOAT)
        {
            // printf("%c",key);//test
            if (float_count++==0)
                float_sum=key-'0';
            else
                float_sum=float_sum*10+(key-'0');
        }
       
        else if( state ==FLOAT_END)
        {
            printf("float\n");
            printf("%d\n",int_sum);
            printf("%lld\n",float_sum);
            break;
        }



        // else if(state==FLOATP)//test
        //     printf("find .\n");

        else if (state ==PRO_FRA)
        {
            // printf("%c",key);//test
            if (float_count++==0)
                float_sum=key-'0';
            else
                float_sum=float_sum*10+(key-'0');
        }
        else if( state ==PRO_FRA_END)
        {
            // printf("intsum=%d,mothersum=%lld\n",int_sum,float_sum);
            if (float_sum>int_sum)
            {
                printf("proper fraction\n");
                break;
            }
            else
                return ERROR;
        }        


        else if (state==ALG_FRAP)
        {
            i=0;
            int_sum=0;
        }
        else if (state==ALG_FRA)
        {  
            if (i++==0)
                int_sum=key-'0';
            else
                int_sum=int_sum*10+(key-'0');
        }
        //判斷帶分數分母
        else if (state ==ALG_FRA_2)
        {
            // printf("%c",key);//test
            if (float_count++==0)
                float_sum=key-'0';
            else
                float_sum=float_sum*10+(key-'0');
        }
        else if( state ==ALG_FRA_2END)
        {
            // printf("ALGintsum=%d,ALGmothersum=%lld\n",int_sum,float_sum);
            if (float_sum>int_sum)
            {
                printf("algebraic fraction\n");
                break;
            }
            else
                return ERROR;
        }        

        else if(state==ERROR)
        {
            // fflush(stdin);  //不行就用下面寫法
            //printf("wrong\n");
            while(1)
            {
                if (key=='\n')
                {
                    //printf("last is /or.\n");
                    break;
                }
                else
                {
                    if (getchar()=='\n')
                    {
                        //printf("eat\n");
                        break;//問一下為什麼能吃到\n
                    }
                }
            }
            return ERROR;
         }
    }
    return state;
}




int judge_state(int state,char key)
{
    if((state==0)&&(isalpha(key)||key=='_'))//進入變數狀態
        return VA;
    else if((state==VA)&&(isalpha(key)||key=='_'||((key-'0'<=9)&&(key-'0'>=0))))//變數的body符合變數歸則
        return VA;
    else if((state==VA)&& key=='\n')//變數狀態成功結尾
        return VA_END;


    else if(state==0&&(key-'0'==0))//開頭為0狀態
        return ZEROCHECK;
    else if(state==ZEROCHECK)
    {
        if (key=='\n')//0的整數
            return ZERO;
        else if (key=='.')
            return FLOATP;//0.XXX的小數
        else
            return ERROR;
    }



    else if (state==0&&((key-'0'<=9)&&(key-'0'>0)))
        return INT;
    else if (state==INT&&((key-'0'<=9)&&(key-'0'>=0)))//整數成功繼續試
        return INT;
    else if((state==INT)&& key=='\n')//整數狀態成功結尾
        return INT_END;
    

    else if (state==INT&& key=='.')//進入可能是小數的狀態試
        return FLOATP;
    else if (state==FLOATP&&((key-'0'<=9)&&(key-'0'>=0)))//進入可能是小數的狀態
    {
        // printf("ffffffloat\n");//test
        return FLOAT;
    }
    else if(state==FLOAT)
        if((key-'0'<=9)&&(key-'0'>=0))
            return FLOAT;
        else if (key=='\n')
            return FLOAT_END;
        else
            return ERROR;
    

    else if (state==INT&& key=='/')//進入可能是真分數的狀態試
        return PRO_FRAP;
    else if (state==PRO_FRAP&&((key-'0'<=9)&&(key-'0'>0)))//進入可能是小數的狀態
        // printf("ffffffloat\n");//test
        return PRO_FRA;

    else if(state==PRO_FRA)
        if((key-'0'<=9)&&(key-'0'>=0))
            return PRO_FRA;
        else if ( key=='\n')
            return PRO_FRA_END;
        else
            return ERROR;

    else if (state==INT&& key=='(')//進入可能是代分數的狀態試,algebraic fraction
        return ALG_FRAP;
    else if (state==ALG_FRAP&& ((key-'0'<=9)&&(key-'0'>0)))//進入可能是帶分數的狀態試
        return ALG_FRA;
    else if (state==ALG_FRA&&((key-'0'<=9)&&(key-'0'>=0)))//
        return ALG_FRA;

    else if (state==ALG_FRA&& key=='/')//進入可能是真分數的狀態試
        return ALG_FRA_2P;
    else if (state==ALG_FRA_2P&&((key-'0'<=9)&&(key-'0'>0)))//進入可能是小數的狀態
    {
        return ALG_FRA_2;
    }

    else if(state==ALG_FRA_2)
    {
        if((key-'0'<=9)&&(key-'0'>=0))
            return ALG_FRA_2;
        else if (key==')')
            return ALG_FRA_2ENDP;
        else
            return ERROR;
    }
    else if (state==ALG_FRA_2ENDP && key=='\n')
        return ALG_FRA_2END;
    else
        return ERROR;//不屬於任一種type

}
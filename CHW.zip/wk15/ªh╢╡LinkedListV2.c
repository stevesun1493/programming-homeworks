/*
31. LinkList多項式運算
本題必須使用Link List實作，否則不予計分。

題目給定兩個多項式，請輸出兩個多項式相加、相減、相乘的結果。

多項式運算結果輸出規範:
1. 輸出計算後從最高次方到0次方的結果。
2. 每一項須輸出係數、x、x的次方數，

每一項輸出格式如下:
1. x的次方數 > 1，輸出ax^k (a為係數，k為次方數)
2. x的次方數 = 1，輸出ax (a為係數)
3. x的次方數 = 0，輸出a (a為係數)
4. 如果所有係數都為0，則該行輸出0

每一項正負號規範:
1. 若該項係數為0，不輸出該項。
2. 若該項的次方數不為多項式的最高次方數，則該項根據係數值的正負數輸出對應的 "+" 或 "-"。
3. 若該項的係數值為1或-1，則不輸出係數值，僅輸出對應的 "+" 或 "-"。

範例:
2 3 0 1 -1
1 0 -1 4 -3 2

根據上方範例輸入，其多項式表示:
多項式一: 2x^4 + 3x^3 + x -1
多項式二: x^5 - x^3 + 4x^2 - 3x +2

根據給定的兩個多項式，其相加、相減、相乘的結果如下:
相加結果: x^5 + 2x^4 + 2x^3 + 4x^2 - 2x + 1
相減結果: -x^5 + 2x^4 + 4x^3 - 4x^2 + 4x - 3
相乘結果: 2x^9 + 3x^8 - 2x^7 + 6x^6 + 5x^5 - 6x^4 + 11x^3 - 7x^2 + 5x - 2

--------------------------------------------------------------------------------------------------------------

輸入說明:
輸入共兩行，每行各代表一個多項式。
每一行輸入 n 個整數，第一個數字代表多項式中 n-1次方項的係數，第 n 個代表多項式中 0 次方項的係數。

輸出說明:
第一行輸出兩個多項式相加的結果
第二行輸出兩個多項式相減的結果
第三行輸出兩個多項式相乘的結果
備註：輸出須符合題目敘述的多項式運算結果輸出規範

--------------------------------------------------------------------------------------------------------------

輸入範例 1:
2 3 0 1 -1
1 0 -1 4 -3 2

輸出範例 1:
x^5+2x^4+2x^3+4x^2-2x+1
-x^5+2x^4+4x^3-4x^2+4x-3
2x^9+3x^8-2x^7+6x^6+5x^5-6x^4+11x^3-7x^2+5x-2

--------------------------------------------------------------------------------------------------------------

輸入範例 2:
3 -7 1 2
7 -1 4

輸出範例 2:
3x^3+6
3x^3-14x^2+2x-2
21x^5-52x^4+26x^3-15x^2+2x+8

--------------------------------------------------------------------------------------------------------------

輸入範例 3:!!
0 0 0 0 0 0 0
1 2 3 4 5 6 7 8

輸出範例 3:
x^7+2x^6+3x^5+4x^4+5x^3+6x^2+7x+8
-x^7-2x^6-3x^5-4x^4-5x^3-6x^2-7x-8
0

--------------------------------------------------------------------------------------------------------------

輸入範例 4:
100 2 3 90 20 -123
5 9 -1 -2 0 0

輸出範例 4:
105x^5+11x^4+2x^3+88x^2+20x-123
95x^5-7x^4+4x^3+92x^2+20x-123
500x^10+910x^9-67x^8+275x^7+903x^6-531x^5-1307x^4+83x^3+246x^2

--------------------------------------------------------------------------------------------------------------

輸入範例5:!!
1 0 0 1
1 0 0 1

輸出範例 5:
2x^3+2
0
x^6+2x^3+1

--------------------------------------------------------------------------------------------------------------

輸入範例 6:!!
-1 0 0 -1
1 0 0 1

輸出範例 6:
0
-2x^3-2
-x^6-2x^3-1

--------------------------------------------------------------------------------------------------------------

輸入範例 7:
0
0

輸出範例 7:
0
0
0

--------------------------------------------------------------------------------------------------------------

輸入範例 8:
1 1 0 0
1 1


輸出範例 8:
x^3+x^2+x+1
x^3+x^2-x-1
x^4+2x^3+x^2
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

typedef struct node_s
{
    int coefficient;
    int power;
    struct node_s* next;
}node_t;
int input(int arr[]);//吃in多項是有幾項
void create_list(node_t**, int arr[],int);//建linked-list
node_t* create_node(int,int);

void copylist(node_t**,node_t*);//(要貼上的list,要複製的list)

node_t* add(node_t*,node_t*);//reurn 新頭
node_t* minus(node_t*,node_t*);
node_t* mul(node_t*,node_t*);
bool check_add(node_t*,node_t*);//頭不會變
bool check_minus(node_t*,node_t*);//頭不會變

node_t* insertOrder(node_t*,node_t*,int);//reurn 新頭
void print(node_t*);

int main()
{
    int coefficient[100]={0},coe_num[2]={0};//裝係數和多項是有幾項
    node_t* *head_ans=(node_t**) malloc(sizeof(node_t*)*3);//存三個答案的串列的頭
    for(int i=0;i<2;i++)//這部有一定要做嗎?
        head_ans[i]=NULL;
    // memset(head_ans,NULL,sizeof(head_ans));好像不能這樣用
    node_t *head1=NULL,*head2=NULL;
// printf("----------------------------------------------------------------------------\n");
    coe_num[0]=input(coefficient);
    // printf("number of coe is %d\n",coe_num[0]);
    create_list(&head1,coefficient,coe_num[0]);
    memset(coefficient,0,sizeof(coefficient));
    coe_num[1]=input(coefficient);
    create_list(&head2,coefficient,coe_num[1]);
    // printf("number of coe is %d\n",coe_num[1]);
    for(int i=0;i<3;i++)
        copylist(&head_ans[i],head1);//應該要用&//test ok
    head_ans[0]=add(head_ans[0],head2);//ok
    head_ans[1]=minus(head_ans[1],head2);
    head_ans[2]=mul(head_ans[2],head2);
    print(head_ans[0]);
    printf("\n");
    print(head_ans[1]);
    printf("\n");
    print(head_ans[2]);
    return 0;
}

void print(node_t* head)
{
    node_t* current = head;
    bool isFirstTerm = true;
    bool isZERO=true;
    while (current != NULL)
    {
        int coefficient = current->coefficient;
        int power = current->power;
        
        if(isZERO && power == 0)
        {
            printf("%d", coefficient);
            return;
        }
        if (coefficient != 0)
        {
            isZERO=false;
            if (!isFirstTerm && coefficient > 0)
                printf("+");
            if (power == 0)
                printf("%d", coefficient);
            else if (power == 1)
            {
                if (coefficient == 1)
                    printf("x");
                else if (coefficient == -1)
                    printf("-x");
                else
                    printf("%dx", coefficient);
            }
            else
            {
                if (coefficient == 1)
                    printf("x^%d", power);
                else if (coefficient == -1)
                    printf("-x^%d", power);
                else
                    printf("%dx^%d", coefficient, power);
            }

            isFirstTerm = false;//!!
        }

        current = current->next;
    }
}




node_t* mul(node_t* added_node,node_t* mul_node)
{
    node_t *newnode,*current=added_node,*newhead=NULL;
    while(mul_node!=NULL)
    {
        // printf("now multiply  %dX^%d\n",mul_node->coefficient,mul_node->power);
        while(current!=NULL)
        {
            newnode=create_node(mul_node->coefficient*current->coefficient, mul_node->power+current->power);
            // printf("\n newnode is  %dX^%d\n",newnode->coefficient,newnode->power);
            // if(!check_add(newhead,newnode))
                newhead=insertOrder(newhead,newnode,1);
            current=current->next;
        }
        current=added_node;//歸位
        mul_node=mul_node->next;
    }
    return newhead;
}


node_t* add(node_t* added_node ,node_t* add_node)
{//add_node要加的節點//added_node被加的節點的頭
    while(add_node!=NULL)//一個一個節點操作
    {
        // if(!check_add(added_node,add_node))//要加的節點次方項不在被加的list內
            added_node=insertOrder(added_node,add_node,1);//接答案的頭(不和上面合成同一個function;因為減和乘還要用)
        add_node=add_node->next;
    }
    return added_node;
}
node_t* minus(node_t* added_node ,node_t* add_node)
{//add_node要加的節點//added_node被加的節點的頭
    while(add_node!=NULL)//一個一個節點操作
    {
        // if(!check_minus(added_node,add_node))//要加的節點次方項不在被加的list內
            added_node=insertOrder(added_node,add_node,0);//接答案的頭(不和上面合成同一個function;因為減和乘還要用)
        add_node=add_node->next;
    }
    return added_node;
}



node_t* insertOrder(node_t*added_node,node_t*add_node,int isAdd)//參考講義的遞迴
{
    node_t *newp;
    if (added_node ==NULL) //add_node的power比所有list裡node的power小or list一開始是空的(不會發生),插最後面
        return create_node(add_node->coefficient,add_node->power); 
    else if (add_node->power > added_node->power) //add_node插前面 ,不會有=的情況
    {
        if(isAdd)
            newp = create_node(add_node->coefficient,add_node->power);
        else//一開始忘記寫(minus得話係數要轉乘-)
            newp = create_node(-1*(add_node->coefficient),add_node->power);
        newp->next = added_node;
        return newp;
    }
    else if (add_node->power == added_node->power)
    {
        if(isAdd)
            added_node->coefficient+=add_node->coefficient;
        else
            added_node->coefficient-=add_node->coefficient;
        return added_node;
    }
    else 
    {
        added_node->next = insertOrder(added_node->next, add_node,isAdd);
        return added_node;
    }
}


int input(int arr[])
{
    int num=1;//多項式樹木
    while(1)//係數有幾個
    {
        scanf("%d",arr+num-1);
        if(getchar()=='\n')
            break;
        num++;
    }
    return num;
}

void create_list(node_t **p, int coe_arr[],int coe_num)
{
    node_t *current=NULL;
    for(int i=coe_num-1;i>=0;i--)
    {
        if(i==coe_num-1)//建頭
        {
            *p=create_node(coe_arr[coe_num-i-1],i);
            current=*p;
        }
        else//身體
        {
            current->next=create_node(coe_arr[coe_num-i-1],i);
            current=current->next;
        }
    }
}
node_t* create_node(int coe,int pow)
{
    node_t *newnode=(node_t*)malloc(sizeof(node_t));
    newnode->coefficient=coe;
    newnode->power=pow;
    newnode->next=NULL;
    return newnode;
}

void copylist(node_t**head,node_t* copy)
{    
    *head=create_node(copy->coefficient,copy->power);//複製頭(題目input一定有東西不可能是NULL)
    node_t* current=*head;//current跟head都指向串鍊頭
    copy=copy->next;
    while(copy!=NULL)
    {
        // printf("ok\n");
        current->next=create_node(copy->coefficient,copy->power);
        copy=copy->next;
        current=current->next;    
    }
}
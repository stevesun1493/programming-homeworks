/*
32. LinkList實作Stack
本題必須使用Link List實作，否則不予計分。

使用Link List模擬stack後進先出（LIFO, Last In First Out）的運作原理。

兩種基本中Stack操作：
push：將資料放入堆疊的頂端（串列形式），堆疊頂端top指標加一。
pop：將頂端資料輸出（回傳），堆疊頂端top指標減一。

題目會給予多個指令，請根據指令輸出結果，其中每一個Stack操作的資料都包含姓名、年齡、生日(年、月、日)。

指令:
1: 代表 push，將姓名、年齡、生日(年、月、日)push進Stack中。
2: 代表 pop，將Stack中頂端的資料pop出來，再根據操作數字進行不同的操作，
操作數字如下:
1: 輸出該次pop的資料中的姓名
2: 輸出該次pop的資料中的年齡
3: 輸出該次pop的資料中的生日 (年、月、日之間以底線連結)
3: 代表 pop直到stack為空，並輸出每一次pop出的資料
4: 代表 print，輸出 stack中所有的資料，但不將資料從stack中移除，輸出的順序同pop，從頂端開始輸出
5: 結束程式，並輸出stack中剩餘的資料數量。

--------------------------------------------------------------------------------------------------------------

輸入說明:
每一行第一個數字為指令，其後為其指令所需的資料。
若指令數字為1，其後資料有姓名、年齡、生日(年、月、日)，資料間以空白相間隔，
若指令數字為2，其後資料有操作數字n (1 <= n <= 3)，
其餘指令數字皆未有資料。

輸出說明:
依照輸入指令，輸出對應的資料，
若當前輸出時，stack為空則輸出 "The Stack is empty"

--------------------------------------------------------------------------------------------------------------

輸入範例 1:
1 Marry 19 1989 7 16
1 Tom 22 1996 10 19
2 1
1 Billy 15 2005 3 18
2 3
2 2
1 Lucas 24 1993 5 21
2 3
2 1
1 Johnson 10 2003 7 10
1 KillerQueen 49 1973 10 21
4
1 GoldExperience 27 1995 9 26
3
5

輸出範例 1:
Tom
2005_3_18
19
1993_5_21
The Stack is empty
KillerQueen 49 1973_10_21
Johnson 10 2003_7_10
GoldExperience 27 1995_9_26
KillerQueen 49 1973_10_21
Johnson 10 2003_7_10
0

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
1 NTUT 20 1999 8 1
1 NTUT 30 1999 7 31
3
4
2 1
1 Andy 14 2004 4 1
5

輸出範例 2：
NTUT 30 1999_7_31
NTUT 20 1999_8_1
The Stack is empty
The Stack is empty
1

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
1 Marry 19 1989 7 16
1 Tom 22 1996 10 19
1 Billy 15 2005 3 18
1 Lucas 24 1993 5 21
2 1
2 2
2 3
2 1
2 2
2 3
5

輸出範例 3：
Lucas
15
1996_10_19
Marry
The Stack is empty
The Stack is empty
0

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
1 Marry 19 1989 7 16
2 1
1 Marry 20 1987 6 17
2 2
1 Marry 21 1986 5 18
2 3
1 Marry 22 1988 4 19
2 1
1 Marry 23 1984 3 10
1 Marry 24 1983 2 11
4
5

輸出範例 4：
Marry
20
1986_5_18
Marry
Marry 24 1983_2_11
Marry 23 1984_3_10
2

--------------------------------------------------------------------------------------------------------------

輸入範例 5：
1 StarPlatinum 17 1970 4 4
1 CrazyDiamond 16 1983 4 1
1 GoldExperience 15 1985 4 16
1 StoneFree 19 1993 1 8
1 SoftandWet 19 2016 7 7
5

輸出範例 5：
5




*/
//用gcc執行都存不了檔為什麼?


#include<stdio.h>
#include<stdlib.h>
typedef struct node_s
{
    char name[20];
    int age;
    int birth[3];//why不能給初值?
    struct node_s* next;
}node_t;

node_t* create_node(void);//void要打嗎?
void push(node_t**);
node_t* pop(node_t**);
void printAll(node_t*top);
int count(node_t*);


int main()  
{
    node_t *top=NULL,*poped_node=NULL;
    
    int command,pop_command;
    while(1)//問下面這坨寫成function是不是比較好?
    {
        scanf("%d",&command);
        if (command==5)
        {
            printf("%d",count(top));
            break;
        }
        else if (command==1)
        {
            push(&top);
        }
        else if(command==2)
        {
            poped_node=pop(&top);
            scanf("%d",&pop_command);
            if(!poped_node)//NULL==0?
            {
                printf("The Stack is empty\n");
                continue;
            }
            else if (pop_command==1)
                puts(poped_node->name);
            else if (pop_command==2)
                printf("%d\n",poped_node->age);
            else 
                printf("%d_%d_%d\n",poped_node->birth[0],poped_node->birth[1],poped_node->birth[2]);
            free (poped_node);
        }
        else if(command==3)
        {
            poped_node=pop(&top);
            while(poped_node!=NULL)
            {
                printf("%s %d %d_%d_%d\n",poped_node->name,poped_node->age,poped_node->birth[0]\
                                                        ,poped_node->birth[1],poped_node->birth[2]);
                free (poped_node);//NULL要free嗎?
                poped_node=pop(&top);
            }
            // printf("The Stack is empty\n");//全部pop完惹pop不了,看起來題目是不用繼續pop
        }
        else if(command==4)
            printAll(top);
    }
    return 0;
}
void push(node_t **top)
{
    node_t* newnode;
    newnode=create_node();
    if(*top==NULL)//push前stack是空的
    {
        // printf("stack is empty\n");
        *top=newnode;
        // printf("push success\n");
    }
    else
    {
        newnode->next=*top;
        *top =newnode;
        // printf("push success\n");
    }
}
node_t* pop(node_t **top)
{
    node_t* poped_node;
    if(*top==NULL)
    {
        // printf("cant't push,stack is empty\n");
        return NULL;
    }
    else
    {
        poped_node=*top;
        *top=(*top)->next;//*top->next這樣好像會錯?
        return poped_node;
    }
}

void printAll(node_t*top)
{
    if(top==NULL)
        printf("The Stack is empty\n");
    while(top!=NULL)
    {
        printf("%s %d %d_%d_%d\n",top->name,top->age,top->birth[0]\
                                            ,top->birth[1],top->birth[2]);
        top=top->next;
    }
}
int count(node_t* temp)
{
    int num=0;
    while(temp!=NULL)
    {
        num++;
        temp=temp->next;
    }
    return num;
}


node_t* create_node()
{
    node_t* newnode=(node_t*)malloc(sizeof(node_t));
    scanf("%s",newnode->name);
    scanf("%d",&newnode->age);
    for(int i=0;i<3;i++)
        scanf("%d",newnode->birth+i);//問是(newnode->birth)+i還是newnode->(birth+i)?
    newnode->next=NULL;
    return newnode;
}





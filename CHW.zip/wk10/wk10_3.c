/*
23. 互補單字
題目給定一個字串S以及數個字串Sn，請輸出這些字串Sn互補的個數。

互補字串定義:
互補字S1, S2的定義是字串S1, S2沒有重複出現的字，
且字串S1, S2內的字需包含在字串S內的字。

此處的字串是英文字的一個集合，亦即英文字即使重複也只算一個，也不需考慮排列情況，
例如 "Happy Happy Day" 與 "Day Happy Day" 是相同的字串。

範例說明:
happy birthday to you
4
happy to you
birthday birthday
to you
happy birthday

第一行為字串S，第二行數字代表之後有n個字串Sn，
第三行為字串S1，第四行為字串S2，依此類推。

互補字串個數計算:
S1(happy to you) 跟 S2(birthday birthday)，S1跟S2的英文字沒有重複，且字串S內的字恰好都被S1, S2所包含，因此為互補字串。
S1(happy to you) 跟 S3(to you)，因為英文字 to 和 you 重複，不是互補字串 。
S1(happy to you) 跟 S4(happy birthday)，因為英文字 happy 重複，不是互補字串。
S2(birthday birthday) 跟 S3(to you)，S1跟S2的字雖然沒重複，但字串S中的英文字happy沒有出現在S1或S2中，因此不是互補字串。
S2(birthday birthday) 跟 S4(happy birthday)，因為英文字 birthday 重複，不是互補字串。
S3(to you) 跟 S4(happy birthday)，S1跟S2的英文字沒有重複，且字串S內的字恰好都被S1, S2所包含，因此為互補字串。
根據上述互補字串個數計算，總共有兩個互補字串，答案為2。

--------------------------------------------------------------------------------------------------------------

輸入範例說明:
第一行為輸入一個字串S，英文文字間以空白相間隔
第二行為輸入一個整數N，代表有N個字串Sn
其後N行，每一行輸入一個字串Sn


輸出範例說明:
輸出互補字串個數計算結果

--------------------------------------------------------------------------------------------------------------

輸入範例 1：
happy birthday to you
4
happy to you
birthday birthday
to you
happy birthday

輸出範例 1：
2

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
red blue green yellow black white
2
red blue green
white yellow black

輸出範例 2：
1

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
APPLE BANANA BANANA APPLE
5
APPLE BANANA APPLE BANANA APPLE
APPLE APPLE APPLE
APPLE BANANA
BANANA BANANA
APPLE BANANA BANANA APPLE

輸出範例 3：
1

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
what are you doing
4
what what are you
you
doing
what are you doing

輸出範例 4：
1

--------------------------------------------------------------------------------------------------------------

輸入範例 5：
pencil pen eraser ruler
6
pencil pen
eraser ruler
pencil eraser ruler
pen
pencil
ruler eraser pen

輸出範例 5：
3

--------------------------------------------------------------------------------------------------------------

輸入範例 6：
GOOGLE APPLE IBM MICROSOFT AMAZON
5
APPLE IBM GOOGLE
GOOGLE MICROSOFT AMAZON
APPLE GOOGLE MICROSOFT AMAZON
GOOGLE IBM IBM GOOGLE
AMAZON AMAZON APPLE GOOGLE

輸出範例 6：
0
*/

#include <stdio.h>
#include<stdlib.h>
#include<string.h>
void input(char main_str[][15],int *);
void  input2(char set_str[][25][15],int arr[],int size);
int count(char main_str[][15],char set_str[][25][15],int setWordnum[],int main_word,int group_num);//算有幾個合法組合
int judgemain(char main_str[][15],int main_wordnum,char set_str[][15],int set_wordnum,char arr[][15],int);//判斷S的單字有沒有全在S1 or S2
int commonWord(char word[],char sentence[][15],int sentenceWordnum);//比較單字有沒有在另一個句子裡
int compareInlist(char str1[][15],int sizesre1,char str2[][15],int sizestr2);//比兩個句子(S1 and S2)有沒有重複的單字
// void input3(char main_str[][25][15],int arr[],int temp);//不需要用之前見的input()就好
int main()
{
    char main_str[100][15]={""};
    int main_num;//主句子有幾個單字
    int size;
    input(main_str,&main_num);
    scanf("%d",&size);
    getchar(); //eat \n
    char set_str[size][25][15];//size組,每組最多25個單字,每個單字最多15個字母
    int setWordnum[20]={0};//用來存每一組有幾個單字(二維部分有幾個)
    input2(set_str,setWordnum,size);
    int total=count(main_str,set_str,setWordnum,main_num,size);

    printf("%d \n",total);


    //下面都是test//ok
    // for(int i=0;i<main_num;i++)
    // puts(main_str[i]);
    // // test
    // printf("test group\n");
    // for(int i=0;i<size;i++)
    // {
    //     printf("group %d has %d words:\n",i,setWordnum[i]);
    //     for(int j=0;j<setWordnum[i];j++)
    //         puts(set_str[i][j]);
    // }

}

void input(char main_str[][15],int *main_num)//把句子一個一個單字存進陣列和紀錄長度
{
    int i=0;
    do
    {
    scanf("%s",main_str[i]);
    i++;
    } while (getchar()!='\n');
    *main_num=i;
}

void  input2(char set_str[][25][15],int num[],int size)//這麼短直接寫在main是不是就好?
{
    for(int i=0;i<size;i++)
        input(set_str[i],&num[i]);//原來三維可以單獨傳二維的部分!

}

int count(char main_str[][15],char set_str[][25][15],int setWordnum[],int main_wordnum,int group_num)
{
    int com_num=0;
    for(int i=0;i<group_num-1;i++)
    {
        for(int j=i+1;j<group_num;j++)
        {
            if(judgemain(main_str,main_wordnum,set_str[i],setWordnum[i],set_str[j],setWordnum[j])&&\
                                !compareInlist(set_str[i],setWordnum[i],set_str[j],setWordnum[j]))
                com_num++;
            else
                continue;
        }   
    }
    return com_num;
}
int judgemain(char main_str[][15],int main_wordnum,char set_str[][15],int set_wordnum,char set_str2[][15],int set_wordnum2)
{
    int state=0;
    for(int i=0;i<main_wordnum;i++)//main的一個一個單字找有沒有在另外兩組裡
        if(commonWord(main_str[i],set_str,set_wordnum)||commonWord(main_str[i],set_str2,set_wordnum2))
            continue;
        else
        {
            state=0;
            return state;
        }
    state=1;
    // printf("all main word in either group\n");
    return state;
}

int compareInlist(char str1[][15],int sizestr1,char str2[][15],int sizestr2)
{
    int state=0;
    for(int i=0;i<sizestr1;i++)//str 1每個單字去看有沒有在str2哩,有代表不合不用繼續找直接return
    {
        if(commonWord(str1[i],str2,sizestr2))
        {
            state=1;//單字有重複
            // printf("sentence 1 is:");
            // for(int k=0;k<sizestr1;k++)
            // {
            //     printf("%s ",str1[k]);
            // }

            // printf("\nsentence2 is:");
            // for(int j=0;j<sizestr2;j++)
            //     printf("%s ",str2[j]);
            // printf("\n");
            // printf("common word is:");
            // puts(str1[i]);
            return state;
        }
    }
    // printf("\n no same word for two group\n");
    return state;//只會是0

}
int commonWord(char word[],char sentence[][15],int sentenceWordnum)
{
    for(int i=0;i<sentenceWordnum;i++)
        if(!strcmp(word,sentence[i]))//靠忘記加驚嘆號...
        {
        //    printf("sentence:");
        //    for(int j=0;j<sentenceWordnum;j++)
        //    {
        //     printf("%s ",sentence[j]);

        //    }
            // printf("\n has common word:%s\n",sentence[i]);
            // printf("result strcmp is:%d\n",strcmp(word,sentence[i]));
            // printf("\n");
           return 1;//有相同單字 
        }
    return 0;
}










































// void input3(char main_str[][25][15],int num[],int temp)//用不到
// {
//     int i=0;
//     do
//     {
//     scanf("%s",main_str[temp][i]);
//     i++;
//     } while (getchar()!='\n');
//     num[temp]=i;
// }
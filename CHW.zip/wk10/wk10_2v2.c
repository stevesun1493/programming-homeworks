/*
22. 交集字元
題目給定兩個字串S及P和一個整數n，將字串P切割成數個長度為n的子字串，
請輸出這些子字串交集字元的個數。

交集字元定義:
交集字元的定義是字串S1, S2有重複出現的字元，
且字串S1, S2內重複的字元需完全相等於在字串S內的字元。

此處的字串是英文字元的一個集合，亦即英文字元即使重複也只算一個，也不需考慮排列情，
例如 "AABAAB"、"ABAB" 與"BABA"是相同的字串。

範例說明:
AABAAB
4
CDECABABABCAABBC

第一行為字串S，
第二行為數字代表以n個字元切割字串P，
第三行為字串P，
切割完成後，會得到n個字串(S1, S2, …., Sn)。

互補字元個數計算:
S1(CDEC) 跟 S2(ABAB)，S1跟S2的英文字元沒有重複，不是交集字元 。
S1(CDEC) 跟 S3(ABCA)，因為英文字元 C 重複，但沒有相等於字串S內的字元，不是交集字元。
S1(CDEC) 跟 S4(ABBC)，因為英文字元 C 重複，但沒有相等於字串S內的字元，不是交集字元。
S2(ABAB) 跟 S3(ABCA)，因為英文字元 A 和 B 重複，且相等於字串S內的字元，因此是交集字元。
S2(ABAB) 跟 S4(ABBC)，因為英文字元 A 和 B 重複，且相等於字串S內的字元，因此是交集字元。
S3(ABCA) 跟 S4(ABBC)，因為英文字元 A 和 B 和 C 重複，但沒有完全相等於字串S內的字元，不是交集字元。

根據上述交集字元個數計算，總共有二個交集字元，答案為2。

--------------------------------------------------------------------------------------------------------------

輸入範例說明:
第一行為輸入一個字串S
第二行為輸入一個整數n (2 < n < 10)
第三行為輸入一個字串P，字串P的長度必為n的整數倍，長度不超過100


輸出範例說明:
輸出交集字元個數計算結果

--------------------------------------------------------------------------------------------------------------

輸入範例 1：
AABAAB
4
CDECABABABCAABBC


輸出範例 1：
2

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
UIKA
3
UIOILUURMFAI


輸出範例 2：
0

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
LUKA
4
APOEZIEOPQKDCMNE


輸出範例 3：
0

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
ADEAE
6
AQPEDCVFYBRTZAZDLEPMKHUYTFDEWAXCFSTHKLQDEA


輸出範例 4：
4

--------------------------------------------------------------------------------------------------------------

輸入範例 5：
CANNOT
7
CAZNLOTIUENOQANPQCTAOMCPGMKHANWOECTMCOSJRS
//CAZNLOT IUENOQA NPQCTAO MCPGMKH ANWOECT MCOSJRS

輸出範例 5：
3

--------------------------------------------------------------------------------------------------------------

輸入範例 6：
POPPING
9
OPIGPPONPPINEURAJDDAMRKZOQRPNIGZPELODAKFWEDOTPQOPGILON


輸出範例 6：
2




*/
//題目敘述好不清楚...
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int count(char main_str[],char str_group[][15],int set_num,int);
int judge(char main_str[],char str1[15],char str2[15],int size);
int judgeInstr(char str[],char letter,int strlen);
// void findletter(char main_str[],char str1[15],char str2[15],int strsize,int *total,char ans_set[]);

int main()
{
    char main_str[15]="";
    char str_group[50][15];//裝分割完的字串
    char temp[100];
    int size;
    scanf("%s",main_str);
    getchar();//eat \n
    scanf("%d",&size);
    getchar();
    scanf("%s",temp);
    char *temp_str=&temp[0];//指向字串頭的指標
    int set_num=strlen(temp)/size;
    for(int i=0;i<set_num;i++)//一個一個字元複製,有沒其他寫法?
    {
        for(int j=0;j<size;j++)
            str_group[i][j]=*(temp_str++);//為啥不能直接寫*(temp++)
        str_group[i][size]='\0';
    }


    //test group//ok
    // for(int i=0;i<set_num;i++)
    //     puts(str_group[i]);//test到這行
    
    int total=count(main_str,str_group,set_num,size);

    // printf("\nthere are total %d group of complete set\n",total);
    printf("%d",total);
    return 0;
}




int count(char main_str[],char str_group[][15],int set_num, int size)//size:集合元素個數(就是每一組的字串長度啦),set_num:集合組數
{
    int total=0;
    // char ans_set[15]="";
    for(int i=0;i<set_num-1;i++)
    {
        for(int j=i+1;j<set_num;j++)
        {
            if(judge(main_str,str_group[i],str_group[j],size))//代表此組合是交集字元(main裡每個字都有同時出現在兩組合字串內?)
            {
                // printf("str1 is:%s and str2 is %s\n",str_group[i],str_group[j]);
                // findletter(main_str,str_group[i],str_group[j],size,&total,ans_set);
                total++;
            }
        }
    }
    return total;
}
// void findletter(char main_str[],char str1[15],char str2[15],int strsize,int *total,char ans_set[])
// {
//     int lenstr=strlen(main_str);

//     for(int i=0;i<lenstr;i++)
//         if(judgeInstr(str1,main_str[i],strsize)&&judgeInstr(str2,main_str[i],strsize))
//         {
//             if(strlen(ans_set)==0)
//             {
//                 ans_set[*total]=main_str[i];
//                 (*total)++;
//                 putchar(main_str[i]);
//             }
//             else
//             {
//                 if(!judgeInstr(ans_set,main_str[i],*total))//還沒被放進去ans_set裡
//                 {
//                     ans_set[*total]=main_str[i];
//                     (*total)++;
//                     putchar(main_str[i]);
//                 }
//                 else
//                     continue;//找main_str的下一個字

//             }
//         }

// }


int judge(char main_str[],char str1[15],char str2[15],int size)//判斷兩種情形,都符合才回傳true
{
    int lenstr=strlen(main_str);
    int state=0;
    for(int i=0;i<lenstr;i++)//先看main_str裡每個字源都有在兩個字串裡
    {
        if(judgeInstr(str1,main_str[i],size)&&judgeInstr(str2,main_str[i],size))
        {
            state=1;
            continue;
        }
        else
        {
            state=0;
            return state;
        }

    }
    for(int i=0;i<size;i++)//看兩個字串裡相同的字源是不是都有在main_str裡
        if(judgeInstr(str2,str1[i],size))
            if(!judgeInstr(main_str,str1[i],lenstr))
            {
                state=0;
                return state;
            }
    return state;


}

int judgeInstr(char str[],char letter,int strlen)
{
    for(int i=0;i<strlen;i++)
        if(letter==str[i])
            return 1; //true:該letter有在str理
    return 0;
}




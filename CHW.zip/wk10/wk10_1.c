/*
21. 文章分析
給定一篇英文文章, 針對文章中的英文文字進行文字操作。

文字操作有以下四種方式，會依據題目給定 2 個英文字(word) P、Q 進行操作:
(1) 文字取代: 將英文文章中 P 字串以 Q 字串取代。
(2) 文字前插入: 在英文文章 A 中 P 字串前插入 Q 字串。
(3) 文字後插入: 在英文文章 A 中 P 字串後插入 Q 字串。
(4) 文字刪除: 將英文文章 A 中 P 字串刪除。
(5) 文字頻率: 分析文章 A 所有英文字 (word) 的頻率,依頻率由大至小排序,頻率相同則以 word 的字典序進行排序(That > This....)。

--------------------------------------------------------------------------------------------------------------

輸入範例說明:
第一行為輸入一篇英文文章 A，文章中的英文文字間以空白相間隔
第二行為輸入一個英文字P
第三行為輸入一個英文字Q


輸出範例說明:
第一行輸出文字取代後的結果
第二行輸出文字前插入後的結果
第三行輸出文字後插入後的結果
第四行輸出文字刪除後的結果
第五行之後,每一行依序輸出排序後的英文字結果 (格式為英文字、出現頻率次數，中間以逗號間隔)

--------------------------------------------------------------------------------------------------------------

輸入範例 1：
Can you can a can as a canner can can a can
can
ban


輸出範例 1：
Can you ban a ban as a canner ban ban a ban
Can you ban can a ban can as a canner ban can ban can a ban can
Can you can ban a can ban as a canner can ban can ban a can ban
Can you a as a canner a
can,5
a,3
Can,1
as,1
canner,1
you,1

--------------------------------------------------------------------------------------------------------------

輸入範例 2：
Whether the weather be cold or whether the weather be hot
the
a


輸出範例 2：
Whether a weather be cold or whether a weather be hot
Whether a the weather be cold or whether a the weather be hot
Whether the a weather be cold or whether the a weather be hot
Whether weather be cold or whether weather be hot
be,2
the,2
weather,2
Whether,1
cold,1
hot,1
or,1
whether,1

--------------------------------------------------------------------------------------------------------------

輸入範例 3：
The bmi doctors want to develop a bmi calculator to help people calculate bmi
bmi
BMI


輸出範例 3：
The BMI doctors want to develop a BMI calculator to help people calculate BMI
The BMI bmi doctors want to develop a BMI bmi calculator to help people calculate BMI bmi
The bmi BMI doctors want to develop a bmi BMI calculator to help people calculate bmi BMI
The doctors want to develop a calculator to help people calculate
bmi,3
to,2
The,1
a,1
calculate,1
calculator,1
develop,1
doctors,1
help,1
people,1
want,1

--------------------------------------------------------------------------------------------------------------

輸入範例 4：
I wish to wish the wish you wish to wish but if you wish the wish the witch wishes I wont wish the wish you wish to wish
wish
wished


輸出範例 4：
I wished to wished the wished you wished to wished but if you wished the wished the witch wishes I wont wished the wished you wished to wished
I wished wish to wished wish the wished wish you wished wish to wished wish but if you wished wish the wished wish the witch wishes I wont wished wish the wished wish you wished wish to wished wish
I wish wished to wish wished the wish wished you wish wished to wish wished but if you wish wished the wish wished the witch wishes I wont wish wished the wish wished you wish wished to wish wished
I to the you to but if you the the witch wishes I wont the you to
wish,11
the,4
to,3
you,3
I,2
but,1
if,1
wishes,1
witch,1
wont,1

--------------------------------------------------------------------------------------------------------------

輸入範例 5：
Fuzzy Wuzzy was a bear and Fuzzy Wuzzy had no hair
Fuzzy
Fuzzer


輸出範例 5：
Fuzzer Wuzzy was a bear and Fuzzer Wuzzy had no hair
Fuzzer Fuzzy Wuzzy was a bear and Fuzzer Fuzzy Wuzzy had no hair
Fuzzy Fuzzer Wuzzy was a bear and Fuzzy Fuzzer Wuzzy had no hair
Wuzzy was a bear and Wuzzy had no hair
Fuzzy,2
Wuzzy,2
and,1//被改判斷順序了...變成字母一樣,長的算比較小
a,1
bear,1
had,1
hair,1
no,1
was,1



*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void replace(char arr[][15],char P[],char Q[], int len,char ans[][15]);//取代
int insert_bf(char arr[][15],char P[],char Q[], int len,char ans[][15]);//前插XD
int insert_bh(char arr[][15],char P[],char Q[], int len,char ans[][15]);//後插XD
int del(char arr[][15],char P[], int len,char ans[][15]);
void display(char str[][15],int len);
int find_word(char str[][15], char ans[][15],int*, int len );
int check_inlist(int len,char *str,  char ans[][15]);
void count(char str[][15],char ans[],int time[],int len,int index);
void pleasehelpsort(char str[][15],int word_time[],int len);
int compare(char str[],char str2[]);//用不到


int main()
{
    char main_str[100][15]={""};//想要讓一為的50個空間都塞""
    /*why 直接寫main_str[10]="apple"是錯的*/
    // for(int i=0;i<50;i++)
    //     strcpy(main_str[i],"");
    // printf("%s\n",strcmp(main_str[30],"")==0?"True":"False");
    // puts(main_str[10]);
    int i=0;
    do
    {

    char temp[15]="";
    scanf("%s",temp);
    strcpy(main_str[i],temp);
    i++;
    } while (getchar()!='\n');
        // printf("total %d words\n",i);//正確
    char P[15]="",Q[15]="";
    scanf("%s",P);
    getchar();
    scanf("%s",Q);
    getchar();
    char replace_str[100][15]={""};/*要重複用同一個arr裝答案還是宣告很多個?如過用同一個要怎麼清空?*/
    char insertbf_str[100][15]={""};
    char insertbh_str[100][15]={""};
    char del_str[100][15]={""};
    int len=i;//單字數量
    replace(main_str,P,Q,len,replace_str);
    display(replace_str,len);
    int newlen=insert_bf(main_str,P,Q,len,insertbf_str);
    display(insertbf_str,newlen);
    newlen=insert_bh(main_str,P,Q,len,insertbh_str);
    display(insertbh_str,newlen);
    newlen=del(main_str,P,len,del_str);
    display(del_str,newlen);

    char difword[50][15];
    int word_time[50]={0};//裝出現次數
    int word_num=find_word(main_str,difword,word_time,len);//ans=[["word"]
    
    // printf("\ntotal %d different words\n",word_num);//ok

    pleasehelpsort(difword,word_time,word_num);
    for(i=0;i<word_num;i++)//ok
        printf("%s,%d\n",difword[i],word_time[i]);
    return 0;
}


int compare(char str[],char str2[])//改題目用不到惹被騙了
{
    for(int i=0;str[i]!='\0'&&str2[i]!='\0';i++)
        if((str2[i]-str[i])<0)//str2字母序比較大要換
            return 1;
        else if((str2[i]-str[i])>0)
            return 0;
    if(strlen(str2)>strlen(str))//字母序都一樣直接比長度,後面比較長要換
        return 1;
    else
        return 0;
}



void pleasehelpsort(char str[][15],int word_time[],int len)
{
    char temp[15]="";
    for(int i=0;i<len-1;i++)
    {
        int maxtime=word_time[i];
        for(int j=i+1;j<len;j++)   
        {
            if(word_time[j]>maxtime)
            {
                strcpy(temp,str[i]);
                strcpy(str[i],str[j]);
                strcpy(str[j],temp);
                
                int temptime=word_time[i];
                word_time[i]=word_time[j];
                word_time[j]=temptime;
                maxtime=word_time[i];
                memset(temp,'\0',15);
            }
            else if(word_time[j]==maxtime)
            {
                if(strcmp(str[i],str[j])>0/*compare(str[i],str[j])*/)//有陷阱,發現要另外寫function不能用strcmp直接判斷...//題目被改了哭阿
                {
                    // printf("change\n");
                    strcpy(temp,str[i]);
                    strcpy(str[i],str[j]);
                    strcpy(str[j],temp);
                    int temptime=word_time[i];
                    word_time[i]=word_time[j];
                    word_time[j]=temptime;
                    maxtime=word_time[i];
                    memset(temp,'\0',15);
                }
            }
        }
    }
}



int find_word(char str[][15], char ans[][15],int time[],int len )
{
    int j=1;//存ans長度(邊界)
    if(len==1)
    {
        strcpy( ans[0],str[0]);
        time[0]=1;
        return j;
    }
    else
    {
        strcpy( ans[0],str[0]);
        for(int i=1;i<len;i++)
            if(check_inlist(j,str[i],ans))//看str[i]有沒有已經被放進過ans,True代表有
                continue;
            else
                strcpy(ans[j++],str[i]);
        for(int i=0;i<j;i++)
            count(str,ans[i],time,len,i);
        return j;

    }
}

void count(char str[][15],char *ans,int time[],int len,int index)
{
    for(int i=0;i<len;i++)
        if(!strcmp(ans,str[i]))//true相等
            time[index]++;
}

int check_inlist(int ans_len,char *str,  char ans[][15])
{
    for(int i=0;i< ans_len;i++)
        if(!strcmp(str,ans[i]))
            return 1;//代表已經放進去過
        else
            continue;
    return 0;//*str這個word還沒放進去過,要加進去ans
}






int del(char str[][15],char P[],int len, char ans[][15])
{
    int j=0;
    for(int i=0;i<len;i++)
    {
        if(!strcmp(str[i],P))
            continue;
        else
            strcpy(ans[j++],str[i]);
        // j++;
    }

    return j;



}




int insert_bh(char str[][15],char P[],char Q[],int len, char ans[][15])
{
    int j=0;
    for(int i=0;i<len;i++)
    {
        if(!strcmp(str[i],P))
        {
            strcpy(ans[j++],P);
            strcpy(ans[j++],Q);
        }
        else
            strcpy(ans[j++],str[i]);
        // j++;
    }

    return j;



}



int insert_bf(char str[][15],char P[],char Q[],int len, char ans[][15])
{
    int j=0;
    for(int i=0;i<len;i++)
    {
        if(!strcmp(str[i],P))
        {
            strcpy(ans[j++],Q);
            strcpy(ans[j++],P);
        }
        else
            strcpy(ans[j++],str[i]);
        // j++;
    }

    return j;



}

void replace(char str[][15],char P[],char Q[],int len, char ans[][15])
{
    for(int i=0;i<len;i++)
        if(!strcmp(str[i],P))//not true
            strcpy(ans[i],Q);
        else
            strcpy(ans[i],str[i]);
}

void display(char str[][15],int len)
{
    for(int i=0;i<len;i++ )
        if(i!=len-1)
            printf("%s ",str[i]);
    
        else
            printf("%s\n",str[i]);
}